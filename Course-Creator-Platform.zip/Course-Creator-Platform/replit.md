# WPS Consulting Group - Academia Virtual

## Plataforma
- **Dominio**: academia.wpsconsultingroup.com
- **Idioma**: Español completo
- **Colores**: Naranja (#DF8700) + Gris (#6C757D)
- **Stack**: Express + Vite + React + PostgreSQL (Drizzle ORM)

## Características Principales
- Cursos al estilo Udemy/Coursera en español
- **Autenticación dual**: Replit Auth (OIDC) para instructor + registro propio (email/password) para estudiantes
- Instructor dashboard para crear/editar cursos y lecciones
- Dashboard de estudiantes con progreso
- Reproductor de video con historial de lecciones
- Catálogo de cursos con vista previa gratuita

## Sistema de Autenticación
- **Instructor**: Usa Replit Auth (`/api/login`) → rol automático `instructor`
- **Estudiantes**: Registro propio en `/register`, login en `/login` → rol `student`
- Endpoint `POST /api/auth/register`: { email, password, firstName, lastName }
- Endpoint `POST /api/auth/login`: { email, password } (passport-local)
- `GET /api/logout`: redirige a home para usuarios locales, OIDC end-session para Replit
- Tabla `users`: columnas `password` (hashed con scrypt) y `role` (student/instructor)
- Helper `getUserId(req)` en routes.ts extrae userId de ambos tipos de sesión

## Pagos
- **PayPal**: `POST /paypal/order`, `/paypal/order/:id/capture` — solo cursos en USD
- **Azul Dominicana**: `POST /api/azul/charge` — incluye ITBIS 18% en DOP
  - En modo mock (sin credenciales Azul) auto-aprueba pagos
  - Credenciales necesarias: `AZUL_MERCHANT_ID`, `AZUL_AUTH1`, `AZUL_AUTH2`
- **CheckoutModal**: muestra ambos tabs para USD; solo Azul para cursos DOP

## Moneda (por curso)
- Campo `currency` en tabla `courses`: `"USD"` o `"DOP"`
- Precios almacenados en centavos (price / 100 = precio real)
- Tarjetas muestran precio con formato Intl (RD$ para DOP, $ para USD)
- Para Azul: convierte USD→DOP con tasa aproximada (58x)

## Sistema de Materiales por Lección
- Tabla `lesson_materials`: id, lessonId, title, type, fileUrl, textContent, fileSize, order
- Tipos soportados: pdf, excel, pptx, docx, text, link, video (mp4/webm/mov)
- Subir archivos: `POST /api/upload/document` (base64, máx 25MB)
- CRUD: `GET/POST /api/lessons/:lessonId/materials`, `PUT/DELETE /api/materials/:id`
- En el reproductor: pestaña "Materiales" muestra archivos descargables y texto

## Sistema de Quizzes/Evaluaciones
- Tablas: `quizzes`, `quiz_questions`, `quiz_attempts`
- Una evaluación por lección con múltiples preguntas de opción múltiple
- Porcentaje mínimo de aprobación configurable (default 70%)
- `POST /api/lessons/:lessonId/quiz` — crear quiz para lección
- `POST /api/quizzes/:id/questions` — agregar pregunta
- `POST /api/quizzes/:id/submit` — enviar respuestas y calcular puntaje
- `GET /api/quizzes/:id/my-attempt` — mejor intento del estudiante
- En el reproductor: pestaña "Evaluación" con preguntas interactivas

## Progreso del Estudiante
- Tabla `lesson_progress`: userId, lessonId, completed
- `POST /api/lessons/:lessonId/complete` — marcar lección como completada
- `GET /api/courses/:courseId/progress` — progreso del usuario en el curso
- Barra de progreso visible en el reproductor

## Subida de Imágenes
- Endpoint: `POST /api/upload/image` (requiere autenticación)
- Acepta base64 JSON — sin dependencias de multer
- Limit: 15MB JSON body
- Archivos guardados en `public/uploads/`
- Servidos estáticamente en `/uploads/`
- Alternativa: pegar URL externa directamente

## Archivos Importantes
- `server/routes.ts` — rutas API principales + upload de imágenes
- `server/paypalRouter.ts` — rutas PayPal (usa createRequire para CommonJS)
- `server/azul.ts` — gateway Azul Dominicana
- `client/src/components/CheckoutModal.tsx` — modal de pago (Azul + PayPal)
- `client/src/components/PayPalButton.tsx` — NO modificar (blueprint PayPal)
- `client/src/pages/EditCourse.tsx` — formulario instructor (imagen + moneda)
- `shared/schema.ts` — esquema de base de datos

## Notas Técnicas
- PayPal SDK ESM fix: `createRequire(import.meta.url)` en paypalRouter.ts
- Rutas wildcard Express: usar `app.use()` no `app.all("/path/*")`
- Variables de entorno: `PAYPAL_CLIENT_ID`, `PAYPAL_CLIENT_SECRET`, `SESSION_SECRET`
