import { Router, type Request, type Response } from "express";
import { createRequire } from "module";

const require = createRequire(import.meta.url);
const paypalSdk = require("@paypal/paypal-server-sdk");

const {
  Client,
  Environment,
  LogLevel,
  OAuthAuthorizationController,
  OrdersController,
} = paypalSdk;

const router = Router();

const { PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET } = process.env;

if (!PAYPAL_CLIENT_ID || !PAYPAL_CLIENT_SECRET) {
  throw new Error("PayPal credentials missing");
}

const client = new Client({
  clientCredentialsAuthCredentials: {
    oAuthClientId: PAYPAL_CLIENT_ID,
    oAuthClientSecret: PAYPAL_CLIENT_SECRET,
  },
  timeout: 0,
  environment:
    process.env.NODE_ENV === "production"
      ? Environment.Production
      : Environment.Sandbox,
  logging: {
    logLevel: LogLevel.Info,
    logRequest: { logBody: true },
    logResponse: { logHeaders: true },
  },
});

const ordersController = new OrdersController(client);
const oAuthAuthorizationController = new OAuthAuthorizationController(client);

async function getClientToken(): Promise<string> {
  const auth = Buffer.from(
    `${PAYPAL_CLIENT_ID}:${PAYPAL_CLIENT_SECRET}`
  ).toString("base64");

  const { result } = await oAuthAuthorizationController.requestToken(
    { authorization: `Basic ${auth}` },
    { intent: "sdk_init", response_type: "client_token" }
  );

  return result.accessToken as string;
}

router.get("/setup", async (_req: Request, res: Response) => {
  try {
    const clientToken = await getClientToken();
    res.json({ clientToken });
  } catch (e) {
    console.error("PayPal setup error:", e);
    res.status(500).json({ error: "Failed to load PayPal." });
  }
});

router.post("/order", async (req: Request, res: Response) => {
  try {
    const { amount, currency, intent } = req.body;

    if (!amount || isNaN(parseFloat(amount)) || parseFloat(amount) <= 0) {
      return res.status(400).json({ error: "Invalid amount." });
    }
    if (!currency) return res.status(400).json({ error: "Currency required." });
    if (!intent) return res.status(400).json({ error: "Intent required." });

    const { body, ...httpResponse } = await ordersController.createOrder({
      body: {
        intent,
        purchaseUnits: [{ amount: { currencyCode: currency, value: amount } }],
      },
      prefer: "return=minimal",
    });

    res.status(httpResponse.statusCode).json(JSON.parse(String(body)));
  } catch (e) {
    console.error("Failed to create PayPal order:", e);
    res.status(500).json({ error: "Failed to create order." });
  }
});

router.post("/order/:orderID/capture", async (req: Request, res: Response) => {
  try {
    const { orderID } = req.params;
    const { body, ...httpResponse } = await ordersController.captureOrder({
      id: orderID,
      prefer: "return=minimal",
    });

    res.status(httpResponse.statusCode).json(JSON.parse(String(body)));
  } catch (e) {
    console.error("Failed to capture PayPal order:", e);
    res.status(500).json({ error: "Failed to capture order." });
  }
});

export default router;
