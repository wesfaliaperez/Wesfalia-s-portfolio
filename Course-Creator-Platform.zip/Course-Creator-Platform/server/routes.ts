import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { isAuthenticated, registerAuthRoutes } from "./replit_integrations/auth";
import { processAzulPayment, isAzulConfigured } from "./azul";
import fs from "fs";
import path from "path";

const __uploadsDir = () => path.join(process.cwd(), "public", "uploads");

function getUserId(req: any): string {
  if (req.user?.userId) return req.user.userId;
  return req.user?.claims?.sub;
}

async function seedDatabase() {
  const existingCourses = await storage.getCourses();
  if (existingCourses.length === 0) {
    try {
      let instructor = await storage.auth.getUser("mock-instructor-id");
      if (!instructor) {
        instructor = await storage.auth.upsertUser({
          id: "mock-instructor-id",
          email: "instructor@wpsconsultingroup.com",
          firstName: "WPS",
          lastName: "Consulting",
          profileImageUrl: "https://wpsconsultingroup.com/img/fondo.png",
          role: "instructor",
        });
      }

      const course1 = await storage.createCourse({
        title: "Inteligencia Artificial para Negocios",
        description: "Aprende a transformar datos en conocimiento accionable utilizando IA y Business Intelligence. Este curso te enseñará desde los fundamentos hasta aplicaciones avanzadas en el entorno empresarial.",
        price: 9900,
        imageUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71",
        published: true,
        instructorId: instructor.id
      });

      await storage.createLesson({ courseId: course1.id, title: "Introducción a la Inteligencia Artificial", description: "Conceptos básicos y aplicaciones en el mundo real de los negocios.", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4", order: 1, isFreePreview: true });
      await storage.createLesson({ courseId: course1.id, title: "Analítica de Datos para la Toma de Decisiones", description: "Herramientas y técnicas para analizar datos empresariales y convertirlos en insights.", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4", order: 2, isFreePreview: false });
      await storage.createLesson({ courseId: course1.id, title: "Machine Learning Aplicado", description: "Implementación de modelos predictivos para casos de uso empresariales reales.", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4", order: 3, isFreePreview: false });

      const course2 = await storage.createCourse({
        title: "Business Intelligence Avanzado",
        description: "Soluciones personalizadas en analítica de datos para tomar decisiones estratégicas. Domina Power BI, Tableau y herramientas líderes del mercado.",
        price: 14900,
        imageUrl: "https://images.unsplash.com/photo-1460925895917-afdab827c52f",
        published: true,
        instructorId: instructor.id
      });

      await storage.createLesson({ courseId: course2.id, title: "Introducción a Business Intelligence", description: "Conceptos clave y ecosistema de herramientas de BI.", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4", order: 1, isFreePreview: true });
      await storage.createLesson({ courseId: course2.id, title: "Modelado y Diseño de Dashboards", description: "Creando estructuras de datos robustas y visualizaciones efectivas.", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4", order: 2, isFreePreview: false });

      await storage.createCourse({
        title: "Consultoría Estratégica de Datos",
        description: "Aprende las metodologías de consultoría utilizadas por firmas líderes para ayudar a las empresas a tomar mejores decisiones basadas en datos.",
        price: 19900,
        imageUrl: "https://images.unsplash.com/photo-1553877522-43269d4ea984",
        published: true,
        instructorId: instructor.id
      });
    } catch (e) {
      console.error("Error seeding database:", e);
    }
  }
}

export async function registerRoutes(httpServer: Server, app: Express): Promise<Server> {
  registerAuthRoutes(app);

  // ─── Image Upload ───
  app.post("/api/upload/image", isAuthenticated, async (req: any, res) => {
    try {
      const { base64, filename } = req.body;
      if (!base64 || !filename) return res.status(400).json({ error: "Datos incompletos." });

      const ext = filename.split(".").pop()?.toLowerCase() || "jpg";
      const allowed = ["jpg", "jpeg", "png", "webp", "gif"];
      if (!allowed.includes(ext)) return res.status(400).json({ error: "Formato no permitido. Use JPG, PNG o WebP." });

      const uploadsDir = __uploadsDir();
      if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

      const safeName = `${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
      const filePath = path.join(uploadsDir, safeName);

      const base64Data = base64.replace(/^data:image\/\w+;base64,/, "");
      fs.writeFileSync(filePath, Buffer.from(base64Data, "base64"));

      res.json({ url: `/uploads/${safeName}` });
    } catch (e) {
      console.error("Upload error:", e);
      res.status(500).json({ error: "Error al subir la imagen." });
    }
  });

  // ─── PayPal Routes ───
  const paypalConfigured = !!(process.env.PAYPAL_CLIENT_ID && process.env.PAYPAL_CLIENT_SECRET);

  if (paypalConfigured) {
    try {
      const paypalRouter = (await import("./paypalRouter")).default;
      app.use("/paypal", paypalRouter);
      console.log("PayPal routes registered successfully.");
    } catch (e) {
      console.warn("PayPal router failed to load:", e);
      app.use("/paypal", (_req, res) => res.status(503).json({ error: "PayPal no disponible." }));
    }
  } else {
    app.use("/paypal", (_req, res) => res.status(503).json({ error: "PayPal no configurado." }));
  }

  // Confirm PayPal purchase after successful payment
  app.post("/api/paypal/confirm-purchase", isAuthenticated, async (req: any, res) => {
    const { courseId, orderID } = req.body;
    const userId = getUserId(req);
    try {
      const already = await storage.hasPurchased(userId, Number(courseId));
      if (!already) {
        await storage.createPurchase({ userId, courseId: Number(courseId), stripeSessionId: `paypal_${orderID}` });
      }
      res.json({ success: true, redirectUrl: `/dashboard/courses/${courseId}/learn` });
    } catch {
      res.status(500).json({ error: "Error al confirmar compra." });
    }
  });

  // ─── Azul Routes ───
  app.post("/api/azul/charge", isAuthenticated, async (req: any, res) => {
    const userId = getUserId(req);
    const { courseId } = req.body;

    if (!isAzulConfigured()) {
      // Mock mode for development — auto-grant access
      try {
        const already = await storage.hasPurchased(userId, Number(courseId));
        if (!already) {
          await storage.createPurchase({ userId, courseId: Number(courseId), stripeSessionId: `mock_azul_${Date.now()}` });
        }
        return res.json({ success: true, authorizationCode: "MOCK-AUTH", message: "Pago procesado (modo prueba)." });
      } catch {
        return res.status(500).json({ error: "Error al registrar compra." });
      }
    }

    // Real Azul payment — intercept the json response
    let azulSuccess = false;
    let azulCode = "";
    const originalJson = res.json.bind(res);
    res.json = function(data: any) {
      if (data?.success) { azulSuccess = true; azulCode = data.authorizationCode; }
      return originalJson(data);
    };

    await processAzulPayment(req, res);

    if (azulSuccess) {
      try {
        const already = await storage.hasPurchased(userId, Number(courseId));
        if (!already) {
          await storage.createPurchase({ userId, courseId: Number(courseId), stripeSessionId: `azul_${azulCode}` });
        }
      } catch (e) {
        console.error("Error registering Azul purchase:", e);
      }
    }
  });

  app.get("/api/payment/status", (_req, res) => {
    res.json({ paypal: paypalConfigured, azul: isAzulConfigured() });
  });

  // ─── Courses ───
  app.get(api.courses.list.path, async (_req, res) => {
    const courses = await storage.getCourses();
    res.json(courses);
  });

  app.get(api.courses.get.path, async (req: any, res) => {
    const course = await storage.getCourse(Number(req.params.id));
    if (!course) return res.status(404).json({ message: 'Curso no encontrado' });

    const userId = req.user?.claims?.sub;
    const isInstructor = userId === course.instructorId;
    const hasPurchased = userId ? await storage.hasPurchased(userId, course.id) : false;

    if (!isInstructor && !hasPurchased && course.lessons) {
      course.lessons = course.lessons.map((lesson: any) =>
        lesson.isFreePreview ? lesson : { ...lesson, videoUrl: null }
      );
    }
    res.json(course);
  });

  app.post(api.courses.create.path, isAuthenticated, async (req: any, res) => {
    try {
      const instructorId = getUserId(req);
      const input = api.courses.create.input.parse(req.body);
      const course = await storage.createCourse({ ...input, instructorId });
      res.status(201).json(course);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      throw err;
    }
  });

  app.put(api.courses.update.path, isAuthenticated, async (req: any, res) => {
    try {
      const courseId = Number(req.params.id);
      const course = await storage.getCourse(courseId);
      if (!course) return res.status(404).json({ message: 'Curso no encontrado' });
      if (course.instructorId !== getUserId(req)) return res.status(401).json({ message: 'No autorizado' });
      const input = api.courses.update.input.parse(req.body);
      const updated = await storage.updateCourse(courseId, input);
      res.status(200).json(updated);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      throw err;
    }
  });

  // ─── Lessons ───
  app.get(api.lessons.list.path, async (req, res) => {
    const lessons = await storage.getLessons(Number(req.params.courseId));
    res.json(lessons);
  });

  app.post(api.lessons.create.path, isAuthenticated, async (req: any, res) => {
    try {
      const courseId = Number(req.params.courseId);
      const course = await storage.getCourse(courseId);
      if (!course) return res.status(404).json({ message: 'Curso no encontrado' });
      if (course.instructorId !== getUserId(req)) return res.status(401).json({ message: 'No autorizado' });
      const input = api.lessons.create.input.parse(req.body);
      const lesson = await storage.createLesson({ ...input, courseId });
      res.status(201).json(lesson);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      throw err;
    }
  });

  app.put(api.lessons.update.path, isAuthenticated, async (req: any, res) => {
    try {
      const lessonId = Number(req.params.id);
      const lesson = await storage.getLesson(lessonId);
      if (!lesson) return res.status(404).json({ message: 'Lección no encontrada' });
      const course = await storage.getCourse(lesson.courseId);
      if (!course || course.instructorId !== getUserId(req)) return res.status(401).json({ message: 'No autorizado' });
      const input = api.lessons.update.input.parse(req.body);
      const updated = await storage.updateLesson(lessonId, input);
      res.status(200).json(updated);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      throw err;
    }
  });

  app.delete(api.lessons.delete.path, isAuthenticated, async (req: any, res) => {
    const lessonId = Number(req.params.id);
    const lesson = await storage.getLesson(lessonId);
    if (!lesson) return res.status(404).json({ message: 'Lección no encontrada' });
    const course = await storage.getCourse(lesson.courseId);
    if (!course || course.instructorId !== getUserId(req)) return res.status(401).json({ message: 'No autorizado' });
    await storage.deleteLesson(lessonId);
    res.status(204).end();
  });

  // ─── Document/File Upload ───
  app.post("/api/upload/document", isAuthenticated, async (req: any, res) => {
    try {
      const { base64, filename } = req.body;
      if (!base64 || !filename) return res.status(400).json({ error: "Datos incompletos." });

      const ext = filename.split(".").pop()?.toLowerCase() || "bin";
      const allowed = ["pdf", "xlsx", "xls", "pptx", "ppt", "docx", "doc", "csv", "txt", "mp4", "webm", "mov"];
      if (!allowed.includes(ext)) return res.status(400).json({ error: "Formato no permitido." });

      const uploadsDir = __uploadsDir();
      if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

      const safeName = `${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
      const filePath = path.join(uploadsDir, safeName);
      const base64Data = base64.replace(/^data:[^;]+;base64,/, "");
      fs.writeFileSync(filePath, Buffer.from(base64Data, "base64"));
      const stats = fs.statSync(filePath);

      res.json({ url: `/uploads/${safeName}`, size: stats.size });
    } catch (e) {
      console.error("Upload error:", e);
      res.status(500).json({ error: "Error al subir el archivo." });
    }
  });

  // ─── Lesson Materials ───
  app.get("/api/lessons/:lessonId/materials", async (req, res) => {
    const materials = await storage.getMaterials(Number(req.params.lessonId));
    res.json(materials);
  });

  app.post("/api/lessons/:lessonId/materials", isAuthenticated, async (req: any, res) => {
    try {
      const lessonId = Number(req.params.lessonId);
      const lesson = await storage.getLesson(lessonId);
      if (!lesson) return res.status(404).json({ error: "Lección no encontrada." });
      const material = await storage.createMaterial({ ...req.body, lessonId });
      res.status(201).json(material);
    } catch (e) {
      res.status(500).json({ error: "Error al crear material." });
    }
  });

  app.put("/api/materials/:id", isAuthenticated, async (req: any, res) => {
    try {
      const m = await storage.updateMaterial(Number(req.params.id), req.body);
      res.json(m);
    } catch {
      res.status(500).json({ error: "Error al actualizar material." });
    }
  });

  app.delete("/api/materials/:id", isAuthenticated, async (req: any, res) => {
    await storage.deleteMaterial(Number(req.params.id));
    res.status(204).end();
  });

  // ─── Quizzes ───
  app.get("/api/lessons/:lessonId/quiz", async (req, res) => {
    const quiz = await storage.getQuiz(Number(req.params.lessonId));
    res.json(quiz);
  });

  app.post("/api/lessons/:lessonId/quiz", isAuthenticated, async (req: any, res) => {
    try {
      const lessonId = Number(req.params.lessonId);
      const existing = await storage.getQuiz(lessonId);
      if (existing) return res.status(400).json({ error: "Ya existe un quiz para esta lección." });
      const quiz = await storage.createQuiz({ ...req.body, lessonId });
      res.status(201).json({ ...quiz, questions: [] });
    } catch (e) {
      res.status(500).json({ error: "Error al crear quiz." });
    }
  });

  app.put("/api/quizzes/:id", isAuthenticated, async (req: any, res) => {
    const q = await storage.updateQuiz(Number(req.params.id), req.body);
    res.json(q);
  });

  app.delete("/api/quizzes/:id", isAuthenticated, async (req: any, res) => {
    await storage.deleteQuiz(Number(req.params.id));
    res.status(204).end();
  });

  app.post("/api/quizzes/:quizId/questions", isAuthenticated, async (req: any, res) => {
    const q = await storage.createQuestion({ ...req.body, quizId: Number(req.params.quizId) });
    res.status(201).json(q);
  });

  app.put("/api/questions/:id", isAuthenticated, async (req: any, res) => {
    const q = await storage.updateQuestion(Number(req.params.id), req.body);
    res.json(q);
  });

  app.delete("/api/questions/:id", isAuthenticated, async (req: any, res) => {
    await storage.deleteQuestion(Number(req.params.id));
    res.status(204).end();
  });

  app.post("/api/quizzes/:quizId/submit", isAuthenticated, async (req: any, res) => {
    try {
      const userId = getUserId(req);
      const quizId = Number(req.params.quizId);
      const { answers } = req.body; // array of selected option indices

      const { db: drizzleDb } = await import("./db");
      const { quizzes: qTable, quizQuestions: qqTable } = await import("@shared/schema");
      const { eq: eqFn, asc: ascFn } = await import("drizzle-orm");
      const [quizRow] = await drizzleDb.select().from(qTable).where(eqFn(qTable.id, quizId));
      if (!quizRow) return res.status(404).json({ error: "Quiz no encontrado." });
      const questions = await drizzleDb.select().from(qqTable).where(eqFn(qqTable.quizId, quizId)).orderBy(ascFn(qqTable.order));
      const quiz = { ...quizRow, questions };

      let correct = 0;
      quiz.questions.forEach((q: any, i: number) => {
        if (answers[i] === q.correctAnswer) correct++;
      });

      const score = quiz.questions.length > 0 ? Math.round((correct / quiz.questions.length) * 100) : 0;
      const passed = score >= quiz.passingScore;

      await storage.submitQuizAttempt(userId, quizId, score, passed, answers);
      res.json({ score, passed, correct, total: quiz.questions.length, passingScore: quiz.passingScore });
    } catch (e) {
      res.status(500).json({ error: "Error al procesar quiz." });
    }
  });

  app.get("/api/quizzes/:quizId/my-attempt", isAuthenticated, async (req: any, res) => {
    const userId = getUserId(req);
    const attempt = await storage.getBestAttempt(userId, Number(req.params.quizId));
    res.json(attempt);
  });

  // ─── Lesson Progress ───
  app.post("/api/lessons/:lessonId/complete", isAuthenticated, async (req: any, res) => {
    const userId = getUserId(req);
    await storage.markLessonComplete(userId, Number(req.params.lessonId));
    res.json({ success: true });
  });

  app.get("/api/courses/:courseId/progress", isAuthenticated, async (req: any, res) => {
    const userId = getUserId(req);
    const completedIds = await storage.getLessonProgress(userId, Number(req.params.courseId));
    res.json({ completedLessonIds: completedIds });
  });

  // ─── Purchases ───
  app.get(api.purchases.list.path, isAuthenticated, async (req: any, res) => {
    const userId = getUserId(req);
    const purchases = await storage.getPurchases(userId);
    res.json(purchases);
  });

  app.post(api.purchases.createCheckout.path, isAuthenticated, async (req: any, res) => {
    const courseId = Number(req.params.courseId);
    const course = await storage.getCourse(courseId);
    if (!course) return res.status(404).json({ message: 'Curso no encontrado' });

    const userId = getUserId(req);
    const alreadyPurchased = await storage.hasPurchased(userId, courseId);
    if (alreadyPurchased) return res.status(400).json({ message: 'Ya adquiriste este curso' });

    await storage.createPurchase({ userId, courseId, stripeSessionId: "direct_" + Date.now() });
    res.json({ url: `/dashboard/courses/${courseId}/learn` });
  });

  await seedDatabase();
  return httpServer;
}
