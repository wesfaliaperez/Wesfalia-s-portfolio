import { db } from "./db";
import {
  courses, lessons, purchases, lessonMaterials, quizzes, quizQuestions, quizAttempts, lessonProgress,
  type CreateCourseRequest, type UpdateCourseRequest, type CourseResponse,
  type CreateLessonRequest, type UpdateLessonRequest, type LessonResponse,
  type PurchaseResponse, type InsertPurchase,
  type LessonMaterial, type InsertLessonMaterial,
  type Quiz, type InsertQuiz,
  type QuizQuestion, type InsertQuizQuestion, type QuizWithQuestions,
} from "@shared/schema";
import { eq, asc, and } from "drizzle-orm";
import { authStorage, IAuthStorage } from "./replit_integrations/auth";

export interface IStorage {
  auth: IAuthStorage;

  getCourses(): Promise<CourseResponse[]>;
  getCourse(id: number): Promise<CourseResponse | undefined>;
  createCourse(course: CreateCourseRequest): Promise<CourseResponse>;
  updateCourse(id: number, updates: UpdateCourseRequest): Promise<CourseResponse>;

  getLessons(courseId: number): Promise<LessonResponse[]>;
  getLesson(id: number): Promise<LessonResponse | undefined>;
  createLesson(lesson: CreateLessonRequest): Promise<LessonResponse>;
  updateLesson(id: number, updates: UpdateLessonRequest): Promise<LessonResponse>;
  deleteLesson(id: number): Promise<void>;

  getMaterials(lessonId: number): Promise<LessonMaterial[]>;
  createMaterial(material: InsertLessonMaterial): Promise<LessonMaterial>;
  updateMaterial(id: number, updates: Partial<InsertLessonMaterial>): Promise<LessonMaterial>;
  deleteMaterial(id: number): Promise<void>;

  getQuiz(lessonId: number): Promise<QuizWithQuestions | null>;
  createQuiz(quiz: InsertQuiz): Promise<Quiz>;
  updateQuiz(id: number, updates: Partial<InsertQuiz>): Promise<Quiz>;
  deleteQuiz(id: number): Promise<void>;
  createQuestion(q: InsertQuizQuestion): Promise<QuizQuestion>;
  updateQuestion(id: number, updates: Partial<InsertQuizQuestion>): Promise<QuizQuestion>;
  deleteQuestion(id: number): Promise<void>;
  submitQuizAttempt(userId: string, quizId: number, score: number, passed: boolean, answers: number[]): Promise<void>;
  getBestAttempt(userId: string, quizId: number): Promise<{ score: number; passed: boolean } | null>;

  getPurchases(userId: string): Promise<PurchaseResponse[]>;
  createPurchase(purchase: InsertPurchase): Promise<PurchaseResponse>;
  hasPurchased(userId: string, courseId: number): Promise<boolean>;

  markLessonComplete(userId: string, lessonId: number): Promise<void>;
  getLessonProgress(userId: string, courseId: number): Promise<number[]>;
}

export class DatabaseStorage implements IStorage {
  auth = authStorage;

  async getCourses(): Promise<CourseResponse[]> {
    const allCourses = await db.select().from(courses);
    return Promise.all(allCourses.map(async (c) => {
      const instructor = await this.auth.getUser(c.instructorId);
      return { ...c, instructor };
    }));
  }

  async getCourse(id: number): Promise<CourseResponse | undefined> {
    const [course] = await db.select().from(courses).where(eq(courses.id, id));
    if (!course) return undefined;
    const instructor = await this.auth.getUser(course.instructorId);
    const courseLessons = await this.getLessons(id);
    return { ...course, instructor, lessons: courseLessons };
  }

  async createCourse(course: CreateCourseRequest): Promise<CourseResponse> {
    const [newCourse] = await db.insert(courses).values(course).returning();
    const instructor = await this.auth.getUser(newCourse.instructorId);
    return { ...newCourse, instructor, lessons: [] };
  }

  async updateCourse(id: number, updates: UpdateCourseRequest): Promise<CourseResponse> {
    const [updated] = await db.update(courses).set(updates).where(eq(courses.id, id)).returning();
    return await this.getCourse(updated.id) as CourseResponse;
  }

  async getLessons(courseId: number): Promise<LessonResponse[]> {
    const raw = await db.select().from(lessons).where(eq(lessons.courseId, courseId)).orderBy(asc(lessons.order));
    return Promise.all(raw.map(async (l) => {
      const materials = await this.getMaterials(l.id);
      const quiz = await this.getQuiz(l.id);
      return { ...l, materials, quiz };
    }));
  }

  async getLesson(id: number): Promise<LessonResponse | undefined> {
    const [lesson] = await db.select().from(lessons).where(eq(lessons.id, id));
    if (!lesson) return undefined;
    const materials = await this.getMaterials(id);
    const quiz = await this.getQuiz(id);
    return { ...lesson, materials, quiz };
  }

  async createLesson(lesson: CreateLessonRequest): Promise<LessonResponse> {
    const [newLesson] = await db.insert(lessons).values(lesson).returning();
    return { ...newLesson, materials: [], quiz: null };
  }

  async updateLesson(id: number, updates: UpdateLessonRequest): Promise<LessonResponse> {
    const [updated] = await db.update(lessons).set(updates).where(eq(lessons.id, id)).returning();
    return await this.getLesson(updated.id) as LessonResponse;
  }

  async deleteLesson(id: number): Promise<void> {
    // Delete dependent records first
    const mats = await db.select().from(lessonMaterials).where(eq(lessonMaterials.lessonId, id));
    for (const m of mats) await db.delete(lessonMaterials).where(eq(lessonMaterials.id, m.id));
    const [quiz] = await db.select().from(quizzes).where(eq(quizzes.lessonId, id));
    if (quiz) {
      await db.delete(quizQuestions).where(eq(quizQuestions.quizId, quiz.id));
      await db.delete(quizAttempts).where(eq(quizAttempts.quizId, quiz.id));
      await db.delete(quizzes).where(eq(quizzes.id, quiz.id));
    }
    await db.delete(lessonProgress).where(eq(lessonProgress.lessonId, id));
    await db.delete(lessons).where(eq(lessons.id, id));
  }

  // ─── Materials ───
  async getMaterials(lessonId: number): Promise<LessonMaterial[]> {
    return db.select().from(lessonMaterials).where(eq(lessonMaterials.lessonId, lessonId)).orderBy(asc(lessonMaterials.order));
  }

  async createMaterial(material: InsertLessonMaterial): Promise<LessonMaterial> {
    const [m] = await db.insert(lessonMaterials).values(material).returning();
    return m;
  }

  async updateMaterial(id: number, updates: Partial<InsertLessonMaterial>): Promise<LessonMaterial> {
    const [m] = await db.update(lessonMaterials).set(updates).where(eq(lessonMaterials.id, id)).returning();
    return m;
  }

  async deleteMaterial(id: number): Promise<void> {
    await db.delete(lessonMaterials).where(eq(lessonMaterials.id, id));
  }

  // ─── Quizzes ───
  async getQuiz(lessonId: number): Promise<QuizWithQuestions | null> {
    const [quiz] = await db.select().from(quizzes).where(eq(quizzes.lessonId, lessonId));
    if (!quiz) return null;
    const questions = await db.select().from(quizQuestions).where(eq(quizQuestions.quizId, quiz.id)).orderBy(asc(quizQuestions.order));
    return { ...quiz, questions };
  }

  async createQuiz(quiz: InsertQuiz): Promise<Quiz> {
    const [q] = await db.insert(quizzes).values(quiz).returning();
    return q;
  }

  async updateQuiz(id: number, updates: Partial<InsertQuiz>): Promise<Quiz> {
    const [q] = await db.update(quizzes).set(updates).where(eq(quizzes.id, id)).returning();
    return q;
  }

  async deleteQuiz(id: number): Promise<void> {
    await db.delete(quizQuestions).where(eq(quizQuestions.quizId, id));
    await db.delete(quizAttempts).where(eq(quizAttempts.quizId, id));
    await db.delete(quizzes).where(eq(quizzes.id, id));
  }

  async createQuestion(q: InsertQuizQuestion): Promise<QuizQuestion> {
    const [question] = await db.insert(quizQuestions).values(q).returning();
    return question;
  }

  async updateQuestion(id: number, updates: Partial<InsertQuizQuestion>): Promise<QuizQuestion> {
    const [q] = await db.update(quizQuestions).set(updates).where(eq(quizQuestions.id, id)).returning();
    return q;
  }

  async deleteQuestion(id: number): Promise<void> {
    await db.delete(quizQuestions).where(eq(quizQuestions.id, id));
  }

  async submitQuizAttempt(userId: string, quizId: number, score: number, passed: boolean, answers: number[]): Promise<void> {
    await db.insert(quizAttempts).values({ userId, quizId, score, passed, answers });
  }

  async getBestAttempt(userId: string, quizId: number): Promise<{ score: number; passed: boolean } | null> {
    const attempts = await db.select().from(quizAttempts)
      .where(and(eq(quizAttempts.userId, userId), eq(quizAttempts.quizId, quizId)));
    if (attempts.length === 0) return null;
    const best = attempts.reduce((a, b) => a.score > b.score ? a : b);
    return { score: best.score, passed: best.passed };
  }

  // ─── Purchases ───
  async getPurchases(userId: string): Promise<PurchaseResponse[]> {
    const all = await db.select().from(purchases).where(eq(purchases.userId, userId));
    return Promise.all(all.map(async (p) => ({ ...p, course: await this.getCourse(p.courseId) })));
  }

  async createPurchase(purchase: InsertPurchase): Promise<PurchaseResponse> {
    const [newPurchase] = await db.insert(purchases).values(purchase).returning();
    return { ...newPurchase, course: await this.getCourse(newPurchase.courseId) };
  }

  async hasPurchased(userId: string, courseId: number): Promise<boolean> {
    const [p] = await db.select().from(purchases).where(and(eq(purchases.userId, userId), eq(purchases.courseId, courseId)));
    return !!p;
  }

  // ─── Progress ───
  async markLessonComplete(userId: string, lessonId: number): Promise<void> {
    const [existing] = await db.select().from(lessonProgress)
      .where(and(eq(lessonProgress.userId, userId), eq(lessonProgress.lessonId, lessonId)));
    if (existing) {
      await db.update(lessonProgress).set({ completed: true, updatedAt: new Date() })
        .where(eq(lessonProgress.id, existing.id));
    } else {
      await db.insert(lessonProgress).values({ userId, lessonId, completed: true });
    }
  }

  async getLessonProgress(userId: string, courseId: number): Promise<number[]> {
    const courseLessons = await db.select().from(lessons).where(eq(lessons.courseId, courseId));
    const lessonIds = courseLessons.map(l => l.id);
    if (lessonIds.length === 0) return [];
    const progress = await db.select().from(lessonProgress)
      .where(eq(lessonProgress.userId, userId));
    return progress.filter(p => lessonIds.includes(p.lessonId) && p.completed).map(p => p.lessonId);
  }
}

export const storage = new DatabaseStorage();
