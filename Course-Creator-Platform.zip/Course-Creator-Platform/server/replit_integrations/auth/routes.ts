import type { Express } from "express";
import passport from "passport";
import { authStorage } from "./storage";
import { isAuthenticated } from "./replitAuth";

// Register auth-specific routes
export function registerAuthRoutes(app: Express): void {
  // Get current authenticated user (works for both Replit and local sessions)
  app.get("/api/auth/user", isAuthenticated, async (req: any, res) => {
    try {
      let userId: string;

      if (req.user?.userId) {
        // Local student session
        userId = req.user.userId;
      } else {
        // Replit OIDC session
        userId = req.user.claims.sub;
      }

      const user = await authStorage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Register a new student account
  app.post("/api/auth/register", async (req, res) => {
    try {
      const { email, password, firstName, lastName } = req.body;

      if (!email || !password || !firstName || !lastName) {
        return res.status(400).json({ message: "Todos los campos son requeridos" });
      }

      if (password.length < 6) {
        return res.status(400).json({ message: "La contraseña debe tener al menos 6 caracteres" });
      }

      const existing = await authStorage.getUserByEmail(email);
      if (existing) {
        return res.status(400).json({ message: "Ya existe una cuenta con este correo electrónico" });
      }

      const user = await authStorage.createLocalUser({ email, password, firstName, lastName });

      // Log in the user immediately after registration
      req.login({ userId: user.id, role: user.role }, (err) => {
        if (err) {
          console.error("Login after register error:", err);
          return res.status(500).json({ message: "Error al iniciar sesión" });
        }
        return res.json({ id: user.id, email: user.email, firstName: user.firstName, lastName: user.lastName, role: user.role });
      });
    } catch (error: any) {
      console.error("Register error:", error);
      res.status(500).json({ message: "Error al crear la cuenta" });
    }
  });

  // Login with email and password
  app.post("/api/auth/login", (req, res, next) => {
    passport.authenticate("local", (err: any, user: any, info: any) => {
      if (err) return next(err);
      if (!user) {
        return res.status(401).json({ message: info?.message || "Credenciales incorrectas" });
      }
      req.login(user, async (loginErr) => {
        if (loginErr) return next(loginErr);
        try {
          const dbUser = await authStorage.getUser(user.userId);
          return res.json(dbUser);
        } catch {
          return res.status(500).json({ message: "Error al obtener usuario" });
        }
      });
    })(req, res, next);
  });
}
