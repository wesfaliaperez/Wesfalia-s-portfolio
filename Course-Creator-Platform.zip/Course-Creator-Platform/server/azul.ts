import { Request, Response } from "express";
import https from "https";

// Azul (Dominican Republic) Payment Gateway integration
// Credentials required: AZUL_MERCHANT_ID, AZUL_AUTH1, AZUL_AUTH2, AZUL_CERTIFICATE_PATH, AZUL_KEY_PATH
// API docs: https://developers.azul.com.do

const AZUL_MERCHANT_ID = process.env.AZUL_MERCHANT_ID;
const AZUL_AUTH1 = process.env.AZUL_AUTH1;
const AZUL_AUTH2 = process.env.AZUL_AUTH2;

const AZUL_URL =
  process.env.NODE_ENV === "production"
    ? "https://pagos.azul.com.do/webservices/JSON/Default.aspx"
    : "https://pruebas.azul.com.do/webservices/JSON/Default.aspx";

export function isAzulConfigured(): boolean {
  return !!(AZUL_MERCHANT_ID && AZUL_AUTH1 && AZUL_AUTH2);
}

export interface AzulChargeRequest {
  cardNumber: string;
  expiry: string; // MMYY format
  cvv: string;
  amount: number; // in cents
  itbis: number; // Dominican tax (18%), in cents
  orderId: string;
  customerName: string;
}

export async function processAzulPayment(req: Request, res: Response) {
  if (!isAzulConfigured()) {
    return res.status(503).json({
      error:
        "Azul no está configurado. Contacte al administrador para activar este método de pago.",
    });
  }

  const {
    cardNumber,
    expiry,
    cvv,
    amount,
    itbis,
    orderId,
    customerName,
  }: AzulChargeRequest = req.body;

  if (!cardNumber || !expiry || !cvv || !amount || !orderId) {
    return res.status(400).json({ error: "Datos de tarjeta incompletos." });
  }

  // Remove spaces from card number
  const cleanCard = cardNumber.replace(/\s+/g, "");

  const payload = {
    Channel: "EC",
    Store: AZUL_MERCHANT_ID,
    CardNumber: cleanCard,
    Expiration: expiry,
    CVC: cvv,
    PosInputMode: "E-Commerce",
    TrxType: "Sale",
    Amount: String(amount), // in centavos (e.g. 9900 = RD$99.00)
    Itbis: String(itbis),
    OrderNumber: orderId,
    ECommerceUrl: process.env.APP_URL || "https://wpsconsultingroup.replit.app",
    CustomerServicePhone: "809-000-0000",
    CustomOrderId: orderId,
    SaveToDataVault: "2",
  };

  try {
    const response = await fetch(AZUL_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Auth1: AZUL_AUTH1!,
        Auth2: AZUL_AUTH2!,
      },
      body: JSON.stringify(payload),
    });

    const data = await response.json() as any;

    if (data.ResponseCode === "00" || data.IsoCode === "00") {
      res.json({
        success: true,
        authorizationCode: data.AuthorizationCode,
        message: "Pago procesado exitosamente.",
      });
    } else {
      res.status(400).json({
        success: false,
        error: data.ResponseMessage || "Pago rechazado. Verifique sus datos.",
      });
    }
  } catch (error) {
    console.error("Azul payment error:", error);
    res.status(500).json({ error: "Error al procesar el pago con Azul." });
  }
}
