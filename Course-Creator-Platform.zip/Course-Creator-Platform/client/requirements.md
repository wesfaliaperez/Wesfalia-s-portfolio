## Packages
date-fns | Formatting dates for course creation and purchases
lucide-react | Icons for the UI

## Notes
- Using `@/hooks/use-auth` for authentication state (already implemented)
- Primary color mapped to `#6C757D`, Accent to `#DF8700`
- Forms require conversion of price (dollars to cents for Stripe/DB)
- API checkout redirects to Stripe URL returned from `/api/courses/:id/checkout`
