import { useState } from "react";
import { useParams, Link } from "wouter";
import { Navbar } from "@/components/layout/Navbar";
import { useCourse } from "@/hooks/use-courses";
import { useLessons } from "@/hooks/use-lessons";
import { usePurchases } from "@/hooks/use-purchases";
import { useAuth } from "@/hooks/use-auth";
import { CheckoutModal } from "@/components/CheckoutModal";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { PlayCircle, Clock, FileText, CheckCircle, Lock, ShieldCheck } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { queryClient } from "@/lib/queryClient";

export default function CourseDetails() {
  const { id } = useParams();
  const courseId = Number(id);
  const { isAuthenticated } = useAuth();
  const [showCheckout, setShowCheckout] = useState(false);

  const { data: course, isLoading: isCourseLoading } = useCourse(courseId);
  const { data: lessons } = useLessons(courseId);
  const { data: purchases } = usePurchases();

  const isPurchased = purchases?.some(p => p.courseId === courseId);
  const fallbackImage = `https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=1200&q=80`;

  const handleBuyClick = () => {
    if (!isAuthenticated) {
      window.location.href = "/api/login";
      return;
    }
    setShowCheckout(true);
  };

  const handlePaymentSuccess = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/purchases"] });
    queryClient.invalidateQueries({ queryKey: ["/api/courses", courseId] });
  };

  if (isCourseLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="max-w-7xl mx-auto px-4 py-12">
          <Skeleton className="h-64 w-full rounded-3xl mb-8" />
          <div className="grid md:grid-cols-3 gap-8">
            <div className="md:col-span-2 space-y-4">
              <Skeleton className="h-12 w-3/4" />
              <Skeleton className="h-6 w-full" />
              <Skeleton className="h-6 w-2/3" />
            </div>
            <Skeleton className="h-64 w-full rounded-2xl" />
          </div>
        </div>
      </div>
    );
  }

  if (!course) return <div className="p-8 text-center">Curso no encontrado</div>;

  const currency = (course as any).currency || "USD";
  const formattedPrice = new Intl.NumberFormat('es-DO', {
    style: 'currency',
    currency,
  }).format(course.price / 100);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />

      {/* Course Header Banner */}
      <div className="bg-gray-900 text-white py-16 lg:py-24 relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <img src={course.imageUrl || fallbackImage} alt="" className="w-full h-full object-cover blur-sm" />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-gray-900/80" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid lg:grid-cols-3 gap-12 items-center">
            <div className="lg:col-span-2">
              <div className="flex items-center gap-2 mb-4 text-white/70 font-medium">
                <span className="uppercase tracking-wider text-sm">Consultoría</span>
                <span>•</span>
                <span>A tu propio ritmo</span>
              </div>
              <h1 className="font-display text-4xl md:text-5xl font-bold mb-6 leading-tight">
                {course.title}
              </h1>
              <p className="text-lg md:text-xl text-white/80 mb-8 max-w-2xl leading-relaxed">
                {course.description}
              </p>
              <div className="flex flex-wrap items-center gap-6 text-sm font-medium">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="h-5 w-5 text-accent" />
                  <span>Certificado verificado</span>
                </div>
                <div className="flex items-center gap-2">
                  <FileText className="h-5 w-5 text-accent" />
                  <span>{lessons?.length || 0} Módulos</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-accent" />
                  <span>A tu propio ritmo</span>
                </div>
              </div>
            </div>

            {/* Purchase Card Desktop */}
            <div className="hidden lg:block">
              <div className="bg-white text-foreground rounded-2xl p-6 shadow-2xl sticky top-24">
                <div className="aspect-video rounded-xl overflow-hidden mb-6 relative group cursor-pointer">
                  <img src={course.imageUrl || fallbackImage} alt={course.title} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                    <PlayCircle className="h-16 w-16 text-white opacity-90" />
                  </div>
                </div>
                <div className="mb-6">
                  <div className="font-display text-4xl font-bold mb-1 text-foreground">
                    {course.price === 0 ? "Gratis" : formattedPrice}
                  </div>
                  <p className="text-muted-foreground text-sm">Acceso de por vida con un solo pago</p>
                </div>

                {isPurchased ? (
                  <Button size="lg" className="w-full h-14 text-lg rounded-xl bg-primary" asChild>
                    <Link href={`/dashboard/courses/${course.id}/learn`}>Ir al Curso</Link>
                  </Button>
                ) : (
                  <Button
                    size="lg"
                    className="w-full h-14 text-lg rounded-xl bg-accent text-white shadow-lg shadow-accent/25"
                    onClick={handleBuyClick}
                    data-testid="button-comprar"
                  >
                    {course.price === 0 ? "Inscribirse Gratis" : "Comprar Ahora"}
                  </Button>
                )}

                <div className="mt-6 space-y-2 text-sm text-muted-foreground">
                  <div className="flex items-center gap-2"><CheckCircle className="h-4 w-4 text-green-500" /> Acceso de por vida</div>
                  <div className="flex items-center gap-2"><CheckCircle className="h-4 w-4 text-green-500" /> Acceso desde cualquier dispositivo</div>
                  <div className="flex items-center gap-2"><CheckCircle className="h-4 w-4 text-green-500" /> Certificado de finalización</div>
                  <div className="flex items-center gap-2"><CheckCircle className="h-4 w-4 text-green-500" /> Pago con Azul o PayPal</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 grid lg:grid-cols-3 gap-12 flex-grow">
        <div className="lg:col-span-2 space-y-12">
          <section>
            <h2 className="font-display text-2xl font-bold mb-4">Acerca de este curso</h2>
            <div className="prose prose-slate max-w-none text-muted-foreground text-base leading-relaxed">
              <p>{course.description}</p>
              <p className="mt-4">
                Este programa completo es diseñado por WPS Consulting Group para brindarte conocimientos accionables y metodologías probadas utilizadas por los mejores consultores a nivel global. Ya sea que busques acelerar tu carrera o impulsar tu negocio, este curso te proporciona los fundamentos y tácticas avanzadas que necesitas.
              </p>
            </div>
          </section>

          <Separator />

          <section>
            <div className="flex items-center justify-between mb-6">
              <h2 className="font-display text-2xl font-bold">Contenido del Curso</h2>
              <span className="text-muted-foreground">{lessons?.length || 0} lecciones</span>
            </div>

            {lessons && lessons.length > 0 ? (
              <Accordion type="multiple" className="w-full space-y-3" defaultValue={lessons.map(l => `item-${l.id}`)}>
                {[...lessons].sort((a, b) => a.order - b.order).map((lesson, idx) => (
                  <AccordionItem
                    key={lesson.id}
                    value={`item-${lesson.id}`}
                    className="border border-border/60 rounded-xl px-4 bg-card shadow-sm overflow-hidden"
                  >
                    <AccordionTrigger className="hover:no-underline py-4">
                      <div className="flex items-center text-left gap-4">
                        <div className="flex items-center justify-center h-8 w-8 rounded-full bg-accent/10 text-accent text-sm font-bold shrink-0">
                          {idx + 1}
                        </div>
                        <div className="flex flex-col">
                          <span className="font-semibold text-foreground">{lesson.title}</span>
                          {lesson.isFreePreview && (
                            <span className="text-xs text-accent font-medium mt-0.5">Vista previa gratuita</span>
                          )}
                        </div>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="pt-2 pb-4 text-muted-foreground">
                      <div className="pl-12">
                        <p className="mb-3">{lesson.description || "Sin descripción."}</p>
                        <div className="flex items-center text-sm font-medium text-accent">
                          {isPurchased || lesson.isFreePreview ? (
                            <Link href={`/dashboard/courses/${course.id}/learn`} className="flex items-center gap-1.5">
                              <PlayCircle className="h-4 w-4" /> Ver lección
                            </Link>
                          ) : (
                            <div className="flex items-center gap-1.5 text-muted-foreground">
                              <Lock className="h-4 w-4" /> Módulo bloqueado
                            </div>
                          )}
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            ) : (
              <div className="p-8 text-center bg-secondary/50 rounded-2xl border border-dashed border-border text-muted-foreground">
                El temario está siendo actualizado. Las lecciones aparecerán pronto.
              </div>
            )}
          </section>
        </div>

        {/* Mobile Purchase Card */}
        <div className="lg:hidden">
          <div className="bg-card rounded-2xl p-6 shadow-xl border border-border/50">
            <div className="font-display text-3xl font-bold mb-2">
              {course.price === 0 ? "Gratis" : formattedPrice}
            </div>
            {isPurchased ? (
              <Button size="lg" className="w-full h-14 rounded-xl bg-primary mt-4" asChild>
                <Link href={`/dashboard/courses/${course.id}/learn`}>Ir al Curso</Link>
              </Button>
            ) : (
              <Button
                size="lg"
                className="w-full h-14 rounded-xl bg-accent text-white mt-4"
                onClick={handleBuyClick}
                data-testid="button-comprar-mobile"
              >
                Comprar Ahora
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Checkout Modal */}
      {course && showCheckout && (
        <CheckoutModal
          open={showCheckout}
          onClose={() => setShowCheckout(false)}
          course={course}
          onPaymentSuccess={handlePaymentSuccess}
        />
      )}
    </div>
  );
}
