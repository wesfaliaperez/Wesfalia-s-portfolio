import { useState, useEffect, useRef } from "react";
import { useParams, useLocation, Link } from "wouter";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Navbar } from "@/components/layout/Navbar";
import { useCourse, useCreateCourse, useUpdateCourse } from "@/hooks/use-courses";
import { useLessons, useCreateLesson, useUpdateLesson, useDeleteLesson } from "@/hooks/use-lessons";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import {
  ArrowLeft, Save, Plus, Trash2, GripVertical, PlayCircle, Loader2, Edit,
  Upload, ImageIcon, X, FileText, FileSpreadsheet, Presentation, File,
  BookOpen, CheckSquare, PlusCircle, AlertCircle
} from "lucide-react";

// ─── Hooks ───
function useImageUpload() {
  const [isUploading, setIsUploading] = useState(false);
  const { toast } = useToast();
  const upload = async (file: File): Promise<string | null> => {
    if (file.size > 10 * 1024 * 1024) {
      toast({ title: "Archivo demasiado grande", description: "Máximo 10MB.", variant: "destructive" });
      return null;
    }
    setIsUploading(true);
    try {
      const base64 = await fileToBase64(file);
      const res = await fetch("/api/upload/image", {
        method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include",
        body: JSON.stringify({ base64, filename: file.name }),
      });
      const data = await res.json();
      if (data.url) return data.url;
      toast({ title: "Error", description: data.error || "No se pudo subir.", variant: "destructive" });
      return null;
    } catch { toast({ title: "Error", description: "No se pudo subir.", variant: "destructive" }); return null; }
    finally { setIsUploading(false); }
  };
  return { upload, isUploading };
}

function useDocumentUpload() {
  const [isUploading, setIsUploading] = useState(false);
  const { toast } = useToast();
  const upload = async (file: File): Promise<{ url: string; size: number } | null> => {
    if (file.size > 25 * 1024 * 1024) {
      toast({ title: "Archivo demasiado grande", description: "Máximo 25MB para documentos.", variant: "destructive" });
      return null;
    }
    setIsUploading(true);
    try {
      const base64 = await fileToBase64(file);
      const res = await fetch("/api/upload/document", {
        method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include",
        body: JSON.stringify({ base64, filename: file.name }),
      });
      const data = await res.json();
      if (data.url) return data;
      toast({ title: "Error", description: data.error || "No se pudo subir.", variant: "destructive" });
      return null;
    } catch { toast({ title: "Error", description: "No se pudo subir.", variant: "destructive" }); return null; }
    finally { setIsUploading(false); }
  };
  return { upload, isUploading };
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function extToType(filename: string): string {
  const ext = filename.split(".").pop()?.toLowerCase() || "";
  if (ext === "pdf") return "pdf";
  if (["xlsx", "xls", "csv"].includes(ext)) return "excel";
  if (["pptx", "ppt"].includes(ext)) return "pptx";
  if (["docx", "doc"].includes(ext)) return "docx";
  if (["mp4", "webm", "mov"].includes(ext)) return "video";
  return "file";
}

function fileIcon(type: string, size = "h-5 w-5") {
  if (type === "pdf") return <FileText className={`${size} text-red-500`} />;
  if (type === "excel") return <FileSpreadsheet className={`${size} text-green-600`} />;
  if (type === "pptx") return <Presentation className={`${size} text-orange-500`} />;
  if (type === "docx") return <FileText className={`${size} text-blue-600`} />;
  if (type === "link") return <BookOpen className={`${size} text-purple-500`} />;
  if (type === "text") return <FileText className={`${size} text-gray-500`} />;
  return <File className={`${size} text-muted-foreground`} />;
}

function fileSizeLabel(bytes?: number | null) {
  if (!bytes) return "";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

// ─── Schemas ───
const courseSchema = z.object({
  title: z.string().min(3, "El título es obligatorio"),
  description: z.string().min(10, "La descripción es obligatoria"),
  priceAmount: z.coerce.number().min(0),
  currency: z.enum(["USD", "DOP"]).default("USD"),
  imageUrl: z.string().optional(),
  published: z.boolean().default(false),
});

const lessonSchema = z.object({
  title: z.string().min(3, "El título es obligatorio"),
  description: z.string().optional(),
  videoUrl: z.string().url("URL inválida").optional().or(z.literal("")),
  isFreePreview: z.boolean().default(false),
});

// ─── Quiz Manager ───
function QuizManager({ lessonId }: { lessonId: number }) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [newQuestion, setNewQuestion] = useState({ question: "", options: ["", "", "", ""], correctAnswer: 0, explanation: "" });
  const [showForm, setShowForm] = useState(false);
  const [editingQId, setEditingQId] = useState<number | null>(null);

  const { data: quiz, isLoading } = useQuery({
    queryKey: ["/api/lessons", lessonId, "quiz"],
    queryFn: async () => {
      const r = await fetch(`/api/lessons/${lessonId}/quiz`, { credentials: "include" });
      return r.ok ? r.json() : null;
    }
  });

  const createQuizMut = useMutation({
    mutationFn: async (title: string) => {
      const r = await apiRequest("POST", `/api/lessons/${lessonId}/quiz`, { title, passingScore: 70 });
      return r.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/lessons", lessonId, "quiz"] });
      queryClient.invalidateQueries({ queryKey: ["/api/courses"] });
    }
  });

  const deleteQuizMut = useMutation({
    mutationFn: async (id: number) => { await apiRequest("DELETE", `/api/quizzes/${id}`, {}); },
    onSuccess: () => {
      toast({ title: "Quiz eliminado." });
      queryClient.invalidateQueries({ queryKey: ["/api/lessons", lessonId, "quiz"] });
      queryClient.invalidateQueries({ queryKey: ["/api/courses"] });
    }
  });

  const addQuestionMut = useMutation({
    mutationFn: async (q: any) => {
      const endpoint = editingQId ? `/api/questions/${editingQId}` : `/api/quizzes/${quiz.id}/questions`;
      const method = editingQId ? "PUT" : "POST";
      const r = await apiRequest(method, endpoint, { ...q, order: quiz?.questions?.length || 0 });
      return r.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/lessons", lessonId, "quiz"] });
      queryClient.invalidateQueries({ queryKey: ["/api/courses"] });
      setNewQuestion({ question: "", options: ["", "", "", ""], correctAnswer: 0, explanation: "" });
      setEditingQId(null);
      setShowForm(false);
    }
  });

  const deleteQuestionMut = useMutation({
    mutationFn: async (id: number) => { await apiRequest("DELETE", `/api/questions/${id}`, {}); },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/lessons", lessonId, "quiz"] });
      queryClient.invalidateQueries({ queryKey: ["/api/courses"] });
      toast({ title: "Pregunta eliminada." });
    }
  });

  const updatePassingMut = useMutation({
    mutationFn: async (ps: number) => {
      await apiRequest("PUT", `/api/quizzes/${quiz.id}`, { title: quiz.title, passingScore: ps });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/lessons", lessonId, "quiz"] });
      queryClient.invalidateQueries({ queryKey: ["/api/courses"] });
    }
  });

  if (isLoading) return <div className="text-sm text-muted-foreground">Cargando...</div>;

  if (!quiz) {
    return (
      <div className="text-center py-8 border-2 border-dashed border-border/50 rounded-xl">
        <CheckSquare className="h-10 w-10 text-muted-foreground mx-auto mb-3 opacity-40" />
        <p className="text-muted-foreground text-sm mb-4">Esta lección no tiene evaluación. Crea una para que los estudiantes puedan demostrar su aprendizaje.</p>
        <Button
          onClick={() => createQuizMut.mutate("Evaluación de la Lección")}
          disabled={createQuizMut.isPending}
          className="bg-accent text-white rounded-xl"
          data-testid="button-crear-quiz"
        >
          <Plus className="h-4 w-4 mr-2" /> Crear Evaluación
        </Button>
      </div>
    );
  }

  const startEdit = (q: any) => {
    setEditingQId(q.id);
    setNewQuestion({ question: q.question, options: [...q.options], correctAnswer: q.correctAnswer, explanation: q.explanation || "" });
    setShowForm(true);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between p-4 bg-accent/5 border border-accent/20 rounded-xl">
        <div>
          <p className="font-semibold text-sm">{quiz.title}</p>
          <p className="text-xs text-muted-foreground">{quiz.questions?.length || 0} preguntas</p>
        </div>
        <div className="flex items-center gap-3">
          <label className="text-xs text-muted-foreground flex items-center gap-1">
            Mínimo para aprobar:
            <select
              value={quiz.passingScore}
              onChange={e => updatePassingMut.mutate(Number(e.target.value))}
              className="ml-1 border border-border rounded px-2 py-1 text-xs"
            >
              {[50, 60, 70, 75, 80, 90, 100].map(n => <option key={n} value={n}>{n}%</option>)}
            </select>
          </label>
          <Button variant="ghost" size="icon" onClick={() => { if (confirm("¿Eliminar este quiz?")) deleteQuizMut.mutate(quiz.id); }} className="text-destructive h-8 w-8">
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {quiz.questions?.map((q: any, idx: number) => (
        <div key={q.id} className="border border-border rounded-xl p-4">
          <div className="flex items-start justify-between gap-2">
            <p className="font-medium text-sm flex gap-2">
              <span className="bg-accent text-white rounded-full w-5 h-5 flex items-center justify-center text-xs shrink-0">{idx + 1}</span>
              {q.question}
            </p>
            <div className="flex gap-1 shrink-0">
              <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => startEdit(q)}><Edit className="h-3.5 w-3.5" /></Button>
              <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => deleteQuestionMut.mutate(q.id)}><Trash2 className="h-3.5 w-3.5" /></Button>
            </div>
          </div>
          <div className="mt-3 grid grid-cols-2 gap-2">
            {q.options.map((opt: string, oi: number) => (
              <div key={oi} className={`text-xs px-3 py-2 rounded-lg border ${oi === q.correctAnswer ? "bg-green-50 border-green-300 text-green-800 font-medium" : "border-border text-muted-foreground"}`}>
                <span className="font-mono opacity-60">{String.fromCharCode(65 + oi)}.</span> {opt}
              </div>
            ))}
          </div>
          {q.explanation && <p className="mt-2 text-xs text-muted-foreground italic bg-muted/50 rounded p-2">{q.explanation}</p>}
        </div>
      ))}

      {showForm ? (
        <div className="border-2 border-accent/30 rounded-xl p-5 bg-accent/5 space-y-4">
          <h4 className="font-semibold text-sm">{editingQId ? "Editar pregunta" : "Nueva pregunta"}</h4>
          <Input
            placeholder="Escribe la pregunta..."
            value={newQuestion.question}
            onChange={e => setNewQuestion(prev => ({ ...prev, question: e.target.value }))}
            className="rounded-lg"
          />
          <div className="space-y-2">
            <p className="text-xs font-medium text-muted-foreground">Opciones de respuesta (marca la correcta)</p>
            {newQuestion.options.map((opt, oi) => (
              <div key={oi} className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setNewQuestion(prev => ({ ...prev, correctAnswer: oi }))}
                  className={`w-6 h-6 rounded-full border-2 flex items-center justify-center shrink-0 transition-colors ${newQuestion.correctAnswer === oi ? "bg-green-500 border-green-500 text-white" : "border-border"}`}
                >
                  {newQuestion.correctAnswer === oi && <span className="text-xs">✓</span>}
                </button>
                <Input
                  placeholder={`Opción ${String.fromCharCode(65 + oi)}`}
                  value={opt}
                  onChange={e => {
                    const opts = [...newQuestion.options];
                    opts[oi] = e.target.value;
                    setNewQuestion(prev => ({ ...prev, options: opts }));
                  }}
                  className="rounded-lg flex-1"
                />
              </div>
            ))}
          </div>
          <Input
            placeholder="Explicación (opcional) — se muestra al estudiante..."
            value={newQuestion.explanation}
            onChange={e => setNewQuestion(prev => ({ ...prev, explanation: e.target.value }))}
            className="rounded-lg"
          />
          <div className="flex gap-2">
            <Button onClick={() => { setShowForm(false); setEditingQId(null); }} variant="ghost" size="sm">Cancelar</Button>
            <Button
              onClick={() => addQuestionMut.mutate(newQuestion)}
              disabled={!newQuestion.question || newQuestion.options.some(o => !o) || addQuestionMut.isPending}
              className="bg-accent text-white rounded-lg"
              size="sm"
            >
              {addQuestionMut.isPending ? "Guardando..." : editingQId ? "Actualizar" : "Agregar"}
            </Button>
          </div>
        </div>
      ) : (
        <Button
          variant="outline"
          className="w-full rounded-xl border-dashed border-2"
          onClick={() => { setEditingQId(null); setNewQuestion({ question: "", options: ["", "", "", ""], correctAnswer: 0, explanation: "" }); setShowForm(true); }}
          data-testid="button-agregar-pregunta"
        >
          <PlusCircle className="h-4 w-4 mr-2" /> Agregar pregunta
        </Button>
      )}
    </div>
  );
}

// ─── Materials Manager ───
function MaterialsManager({ lessonId }: { lessonId: number }) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { upload: uploadDoc, isUploading } = useDocumentUpload();
  const docFileRef = useRef<HTMLInputElement>(null);
  const [showLinkForm, setShowLinkForm] = useState(false);
  const [showTextForm, setShowTextForm] = useState(false);
  const [linkTitle, setLinkTitle] = useState("");
  const [linkUrl, setLinkUrl] = useState("");
  const [textTitle, setTextTitle] = useState("");
  const [textContent, setTextContent] = useState("");

  const { data: materials = [], isLoading } = useQuery({
    queryKey: ["/api/lessons", lessonId, "materials"],
    queryFn: async () => {
      const r = await fetch(`/api/lessons/${lessonId}/materials`, { credentials: "include" });
      return r.ok ? r.json() : [];
    }
  });

  const addMut = useMutation({
    mutationFn: async (data: any) => {
      const r = await apiRequest("POST", `/api/lessons/${lessonId}/materials`, data);
      return r.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/lessons", lessonId, "materials"] });
      queryClient.invalidateQueries({ queryKey: ["/api/courses"] });
    }
  });

  const deleteMut = useMutation({
    mutationFn: async (id: number) => { await apiRequest("DELETE", `/api/materials/${id}`, {}); },
    onSuccess: () => {
      toast({ title: "Material eliminado." });
      queryClient.invalidateQueries({ queryKey: ["/api/lessons", lessonId, "materials"] });
      queryClient.invalidateQueries({ queryKey: ["/api/courses"] });
    }
  });

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const result = await uploadDoc(file);
    if (result) {
      await addMut.mutateAsync({ title: file.name, type: extToType(file.name), fileUrl: result.url, fileSize: result.size, order: materials.length });
      toast({ title: "Archivo subido exitosamente." });
    }
    e.target.value = "";
  };

  const handleAddLink = async () => {
    if (!linkTitle || !linkUrl) return;
    await addMut.mutateAsync({ title: linkTitle, type: "link", fileUrl: linkUrl, order: materials.length });
    setLinkTitle(""); setLinkUrl(""); setShowLinkForm(false);
  };

  const handleAddText = async () => {
    if (!textTitle || !textContent) return;
    await addMut.mutateAsync({ title: textTitle, type: "text", textContent, order: materials.length });
    setTextTitle(""); setTextContent(""); setShowTextForm(false);
  };

  if (isLoading) return <div className="text-sm text-muted-foreground">Cargando...</div>;

  return (
    <div className="space-y-4">
      {/* Upload buttons */}
      <div className="grid sm:grid-cols-3 gap-3">
        <input ref={docFileRef} type="file" accept=".pdf,.xlsx,.xls,.csv,.pptx,.ppt,.docx,.doc,.txt,.mp4,.webm,.mov" className="hidden" onChange={handleFileUpload} />
        <Button variant="outline" className="rounded-xl h-auto py-3 flex-col gap-1" onClick={() => docFileRef.current?.click()} disabled={isUploading}>
          <Upload className="h-5 w-5 text-accent" />
          <span className="text-xs">{isUploading ? "Subiendo..." : "Subir archivo"}</span>
          <span className="text-[10px] text-muted-foreground">PDF, Excel, PPT, Word, MP4...</span>
        </Button>
        <Button variant="outline" className="rounded-xl h-auto py-3 flex-col gap-1" onClick={() => { setShowLinkForm(true); setShowTextForm(false); }}>
          <BookOpen className="h-5 w-5 text-purple-500" />
          <span className="text-xs">Agregar enlace</span>
          <span className="text-[10px] text-muted-foreground">URL externa</span>
        </Button>
        <Button variant="outline" className="rounded-xl h-auto py-3 flex-col gap-1" onClick={() => { setShowTextForm(true); setShowLinkForm(false); }}>
          <FileText className="h-5 w-5 text-gray-500" />
          <span className="text-xs">Texto / Notas</span>
          <span className="text-[10px] text-muted-foreground">Contenido escrito</span>
        </Button>
      </div>

      {/* Link form */}
      {showLinkForm && (
        <div className="border border-border rounded-xl p-4 space-y-3 bg-purple-50/30">
          <Input placeholder="Título del enlace" value={linkTitle} onChange={e => setLinkTitle(e.target.value)} className="rounded-lg" />
          <Input placeholder="https://..." value={linkUrl} onChange={e => setLinkUrl(e.target.value)} className="rounded-lg" />
          <div className="flex gap-2">
            <Button size="sm" variant="ghost" onClick={() => setShowLinkForm(false)}>Cancelar</Button>
            <Button size="sm" className="bg-accent text-white rounded-lg" onClick={handleAddLink} disabled={!linkTitle || !linkUrl || addMut.isPending}>
              Agregar enlace
            </Button>
          </div>
        </div>
      )}

      {/* Text form */}
      {showTextForm && (
        <div className="border border-border rounded-xl p-4 space-y-3 bg-gray-50/50">
          <Input placeholder="Título del texto/notas" value={textTitle} onChange={e => setTextTitle(e.target.value)} className="rounded-lg" />
          <Textarea placeholder="Escribe el contenido, apuntes o notas de la lección..." value={textContent} onChange={e => setTextContent(e.target.value)} className="min-h-[120px] rounded-lg" />
          <div className="flex gap-2">
            <Button size="sm" variant="ghost" onClick={() => setShowTextForm(false)}>Cancelar</Button>
            <Button size="sm" className="bg-accent text-white rounded-lg" onClick={handleAddText} disabled={!textTitle || !textContent || addMut.isPending}>
              Guardar texto
            </Button>
          </div>
        </div>
      )}

      {/* Material list */}
      {materials.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground text-sm border-2 border-dashed border-border/40 rounded-xl">
          <File className="h-8 w-8 mx-auto mb-2 opacity-30" />
          No hay materiales aún. Sube archivos, agrega enlaces o escribe notas.
        </div>
      ) : (
        <div className="space-y-2">
          {materials.map((mat: any) => (
            <div key={mat.id} className="flex items-center gap-3 p-3 border border-border rounded-xl bg-gray-50">
              {fileIcon(mat.type, "h-4 w-4")}
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{mat.title}</p>
                <p className="text-xs text-muted-foreground uppercase">
                  {mat.type} {mat.fileSize ? `· ${fileSizeLabel(mat.fileSize)}` : ""}
                </p>
              </div>
              <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive shrink-0" onClick={() => deleteMut.mutate(mat.id)}>
                <Trash2 className="h-3.5 w-3.5" />
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Lesson Dialog ───
function LessonDialog({ lessonId, courseId, onClose, onSaved }: { lessonId: number | null; courseId: number; onClose: () => void; onSaved?: () => void }) {
  const { toast } = useToast();
  const isNew = lessonId === null;
  const createLesson = useCreateLesson(courseId);
  const updateLesson = useUpdateLesson(courseId);
  const { data: lessons } = useLessons(courseId);
  const [currentLessonId, setCurrentLessonId] = useState<number | null>(lessonId);

  const lessonData = lessons?.find((l: any) => l.id === currentLessonId);

  const form = useForm<z.infer<typeof lessonSchema>>({
    resolver: zodResolver(lessonSchema),
    defaultValues: { title: "", description: "", videoUrl: "", isFreePreview: false },
  });

  useEffect(() => {
    if (lessonData) {
      form.reset({
        title: lessonData.title,
        description: lessonData.description || "",
        videoUrl: lessonData.videoUrl || "",
        isFreePreview: lessonData.isFreePreview,
      });
    }
  }, [lessonData]);

  const onSubmitBasic = async (values: z.infer<typeof lessonSchema>) => {
    const payload = { ...values, videoUrl: values.videoUrl || null, order: lessons?.length || 0 };
    if (isNew || !currentLessonId) {
      createLesson.mutate(payload as any, {
        onSuccess: (data: any) => {
          toast({ title: "Lección creada." });
          setCurrentLessonId(data.id);
          onSaved?.();
        }
      });
    } else {
      updateLesson.mutate({ id: currentLessonId, ...payload } as any, {
        onSuccess: () => { toast({ title: "Lección actualizada." }); onSaved?.(); }
      });
    }
  };

  return (
    <DialogContent className="sm:max-w-[680px] p-0 overflow-hidden rounded-2xl max-h-[90vh] flex flex-col">
      <DialogHeader className="px-6 py-4 border-b border-border/50 bg-gray-50 shrink-0">
        <DialogTitle>{isNew && !currentLessonId ? "Agregar Nueva Lección" : "Editar Lección"}</DialogTitle>
      </DialogHeader>

      <div className="flex-1 overflow-y-auto">
        <Tabs defaultValue="info" className="flex flex-col h-full">
          <div className="px-6 pt-4 pb-0 border-b border-border/30 bg-white shrink-0">
            <TabsList className="h-10">
              <TabsTrigger value="info" className="text-sm">Información</TabsTrigger>
              <TabsTrigger value="materials" disabled={!currentLessonId} className="text-sm">
                Materiales {!currentLessonId && <span className="ml-1 text-xs opacity-50">(guardar primero)</span>}
              </TabsTrigger>
              <TabsTrigger value="quiz" disabled={!currentLessonId} className="text-sm">
                Evaluación {!currentLessonId && <span className="ml-1 text-xs opacity-50">(guardar primero)</span>}
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="info" className="p-6 mt-0">
            <Form {...form}>
              <form className="space-y-5">
                <FormField control={form.control} name="title" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Título de la Lección</FormLabel>
                    <FormControl><Input placeholder="Ej: Introducción al Framework" className="rounded-xl" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="videoUrl" render={({ field }) => (
                  <FormItem>
                    <FormLabel>URL del Video</FormLabel>
                    <FormControl><Input placeholder="https://... (MP4 directo, YouTube embed, Vimeo...)" className="rounded-xl" {...field} /></FormControl>
                    <FormDescription>Enlace directo a un archivo .mp4 o URL de reproductor compatible.</FormDescription>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="description" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Contenido / Descripción de la Lección</FormLabel>
                    <FormControl><Textarea className="min-h-[120px] rounded-xl" placeholder="Explica el contenido, objetivos o apuntes de esta lección..." {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="isFreePreview" render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-xl border border-border/50 p-4 bg-gray-50">
                    <div>
                      <FormLabel>Vista Previa Gratuita</FormLabel>
                      <FormDescription>Estudiantes sin comprar podrán ver esta lección.</FormDescription>
                    </div>
                    <FormControl><Switch checked={field.value} onCheckedChange={field.onChange} /></FormControl>
                  </FormItem>
                )} />
              </form>
            </Form>
          </TabsContent>

          {currentLessonId && (
            <TabsContent value="materials" className="p-6 mt-0">
              <MaterialsManager lessonId={currentLessonId} />
            </TabsContent>
          )}

          {currentLessonId && (
            <TabsContent value="quiz" className="p-6 mt-0">
              <QuizManager lessonId={currentLessonId} />
            </TabsContent>
          )}
        </Tabs>
      </div>

      <div className="px-6 py-4 border-t border-border/50 bg-gray-50 shrink-0 flex justify-between">
        <DialogClose asChild>
          <Button variant="ghost">Cerrar</Button>
        </DialogClose>
        <Button
          onClick={form.handleSubmit(onSubmitBasic)}
          disabled={createLesson.isPending || updateLesson.isPending}
          className="bg-accent text-white rounded-xl"
          data-testid="button-guardar-leccion"
        >
          {createLesson.isPending || updateLesson.isPending ? "Guardando..." : currentLessonId && !isNew ? "Actualizar lección" : "Crear lección"}
        </Button>
      </div>
    </DialogContent>
  );
}

// ─── Lesson Manager ───
function LessonManager({ courseId, lessons }: { courseId: number; lessons: any[] }) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const deleteLesson = useDeleteLesson(courseId);
  const { toast } = useToast();

  const sortedLessons = [...lessons].sort((a, b) => a.order - b.order);

  const openNew = () => { setEditingId(null); setDialogOpen(true); };
  const openEdit = (id: number) => { setEditingId(id); setDialogOpen(true); };

  const handleDelete = (id: number) => {
    if (confirm("¿Eliminar esta lección y todos sus materiales y evaluaciones?")) {
      deleteLesson.mutate(id, { onSuccess: () => toast({ title: "Lección eliminada." }) });
    }
  };

  return (
    <div className="bg-white p-6 md:p-8 rounded-2xl border border-border/50 shadow-sm">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="font-display font-bold text-xl">Plan de Estudios</h2>
          <p className="text-sm text-muted-foreground">Gestiona lecciones, materiales y evaluaciones</p>
        </div>
        <Button onClick={openNew} variant="outline" className="rounded-xl border-dashed border-2" data-testid="button-agregar-leccion">
          <Plus className="h-4 w-4 mr-2" /> Agregar Lección
        </Button>
      </div>

      {sortedLessons.length === 0 ? (
        <div className="text-center py-12 border-2 border-dashed border-border/60 rounded-xl bg-gray-50">
          <PlayCircle className="h-12 w-12 text-muted-foreground mx-auto mb-3 opacity-50" />
          <p className="text-muted-foreground">Aún no hay lecciones. ¡Agrega la primera!</p>
        </div>
      ) : (
        <div className="space-y-3">
          {sortedLessons.map((lesson, idx) => {
            const matCount = lesson.materials?.length || 0;
            const hasQuiz = !!lesson.quiz;
            return (
              <div key={lesson.id} className="flex items-center gap-3 p-4 bg-gray-50 border border-border rounded-xl group" data-testid={`item-lesson-${lesson.id}`}>
                <div className="cursor-grab text-muted-foreground opacity-40"><GripVertical className="h-5 w-5" /></div>
                <div className="w-8 h-8 rounded-full bg-accent/10 text-accent text-sm font-bold flex items-center justify-center shrink-0">{idx + 1}</div>
                <div className="flex-1 flex flex-col min-w-0">
                  <span className="font-medium text-foreground text-sm truncate">{lesson.title}</span>
                  <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                    {lesson.videoUrl && <Badge variant="secondary" className="text-[10px] h-4 px-1.5"><PlayCircle className="h-2.5 w-2.5 mr-0.5" />Video</Badge>}
                    {matCount > 0 && <Badge variant="secondary" className="text-[10px] h-4 px-1.5"><File className="h-2.5 w-2.5 mr-0.5" />{matCount} archivo{matCount > 1 ? "s" : ""}</Badge>}
                    {hasQuiz && <Badge className="text-[10px] h-4 px-1.5 bg-accent/10 text-accent"><CheckSquare className="h-2.5 w-2.5 mr-0.5" />Quiz</Badge>}
                    {lesson.isFreePreview && <Badge variant="outline" className="text-[10px] h-4 px-1.5">Vista previa gratis</Badge>}
                  </div>
                </div>
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button variant="ghost" size="icon" onClick={() => openEdit(lesson.id)} className="h-8 w-8"><Edit className="h-4 w-4" /></Button>
                  <Button variant="ghost" size="icon" onClick={() => handleDelete(lesson.id)} className="h-8 w-8 text-destructive"><Trash2 className="h-4 w-4" /></Button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        {dialogOpen && (
          <LessonDialog
            lessonId={editingId}
            courseId={courseId}
            onClose={() => setDialogOpen(false)}
            onSaved={() => {}}
          />
        )}
      </Dialog>
    </div>
  );
}

// ─── Main EditCourse Component ───
export default function EditCourse() {
  const { id } = useParams();
  const isNew = !id || id === "new";
  const courseId = isNew ? 0 : Number(id);
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { upload: uploadImage, isUploading: isUploadingImg } = useImageUpload();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { data: course, isLoading: isCourseLoading } = useCourse(isNew ? 0 : courseId);
  const { data: lessons } = useLessons(courseId);

  const createCourse = useCreateCourse();
  const updateCourse = useUpdateCourse(courseId);

  const form = useForm<z.infer<typeof courseSchema>>({
    resolver: zodResolver(courseSchema),
    defaultValues: { title: "", description: "", priceAmount: 0, currency: "USD", imageUrl: "", published: false },
  });

  const watchCurrency = form.watch("currency");
  const watchImageUrl = form.watch("imageUrl");
  const currencySymbol = watchCurrency === "DOP" ? "RD$" : "$";

  useEffect(() => {
    if (course && !isNew) {
      const curr = (course as any).currency || "USD";
      form.reset({
        title: course.title,
        description: course.description,
        priceAmount: course.price / 100,
        currency: curr,
        imageUrl: course.imageUrl || "",
        published: course.published,
      });
    }
  }, [course, isNew, form]);

  const handleImageFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = await uploadImage(file);
    if (url) form.setValue("imageUrl", url);
    e.target.value = "";
  };

  const onSubmit = (values: z.infer<typeof courseSchema>) => {
    const payload = {
      title: values.title,
      description: values.description,
      price: Math.round(values.priceAmount * 100),
      currency: values.currency,
      imageUrl: values.imageUrl || null,
      published: values.published,
    };

    if (isNew) {
      createCourse.mutate(payload as any, {
        onSuccess: (data: any) => {
          toast({ title: "¡Curso creado!" });
          setLocation(`/instructor/courses/${data.id}/edit`);
        },
        onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" })
      });
    } else {
      updateCourse.mutate(payload as any, {
        onSuccess: () => toast({ title: "¡Curso actualizado!" }),
        onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" })
      });
    }
  };

  const isSaving = createCourse.isPending || updateCourse.isPending;
  if (!isNew && isCourseLoading) return <div className="p-12 text-center text-muted-foreground">Cargando...</div>;

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <Navbar />

      <div className="bg-white border-b border-border/50 sticky top-16 z-30 shadow-sm">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" asChild className="rounded-full">
              <Link href="/instructor"><ArrowLeft className="h-5 w-5" /></Link>
            </Button>
            <h1 className="font-display font-bold text-xl">
              {isNew ? "Crear Nuevo Curso" : "Editar Curso"}
            </h1>
          </div>
          <Button onClick={form.handleSubmit(onSubmit)} disabled={isSaving} className="bg-accent text-white rounded-full px-6 shadow-md" data-testid="button-guardar">
            {isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
            {isNew ? "Crear y Continuar" : "Guardar Cambios"}
          </Button>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">

            {/* Course info form */}
            <div className="bg-white p-6 md:p-8 rounded-2xl border border-border/50 shadow-sm">
              <h2 className="font-display font-bold text-xl mb-6">Información del Curso</h2>
              <Form {...form}>
                <form className="space-y-6">
                  <FormField control={form.control} name="title" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Título del Curso</FormLabel>
                      <FormControl><Input placeholder="Ej: Estrategias Avanzadas de Consultoría" className="text-base py-6 rounded-xl" {...field} data-testid="input-titulo" /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />

                  <FormField control={form.control} name="description" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Descripción</FormLabel>
                      <FormControl>
                        <Textarea placeholder="¿Qué aprenderán los estudiantes?" className="min-h-[140px] resize-y rounded-xl" {...field} data-testid="input-descripcion" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />

                  <div className="grid sm:grid-cols-2 gap-6">
                    <FormField control={form.control} name="currency" render={({ field }) => (
                      <FormItem>
                        <FormLabel>Moneda</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger className="py-6 rounded-xl" data-testid="select-moneda">
                              <SelectValue placeholder="Seleccionar moneda" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="USD">🇺🇸 Dólares (USD)</SelectItem>
                            <SelectItem value="DOP">🇩🇴 Pesos Dominicanos (DOP)</SelectItem>
                          </SelectContent>
                        </Select>
                      </FormItem>
                    )} />

                    <FormField control={form.control} name="priceAmount" render={({ field }) => (
                      <FormItem>
                        <FormLabel>Precio ({watchCurrency})</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">{currencySymbol}</span>
                            <Input type="number" step="0.01" min="0" className="pl-10 py-6 rounded-xl" {...field} data-testid="input-precio" />
                          </div>
                        </FormControl>
                        <FormDescription>0 para curso gratuito.</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )} />
                  </div>

                  {/* Image upload */}
                  <FormField control={form.control} name="imageUrl" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Imagen de Portada</FormLabel>
                      {watchImageUrl && (
                        <div className="relative rounded-xl overflow-hidden border border-border mb-3" style={{ aspectRatio: "16/9" }}>
                          <img src={watchImageUrl} alt="Portada" className="w-full h-full object-cover" />
                          <Button type="button" variant="ghost" size="icon" className="absolute top-2 right-2 bg-black/50 text-white rounded-full h-8 w-8" onClick={() => form.setValue("imageUrl", "")}>
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      )}
                      <input ref={fileInputRef} type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={handleImageFile} />
                      <Button type="button" variant="outline" className="w-full rounded-xl" onClick={() => fileInputRef.current?.click()} disabled={isUploadingImg} data-testid="button-subir-imagen">
                        {isUploadingImg ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Subiendo...</> : <><Upload className="mr-2 h-4 w-4" />Subir desde tu computadora</>}
                      </Button>
                      <div className="flex items-center gap-2 mt-2">
                        <div className="flex-1 h-px bg-border" /><span className="text-xs text-muted-foreground">o pega una URL</span><div className="flex-1 h-px bg-border" />
                      </div>
                      <FormControl>
                        <Input placeholder="https://..." className="rounded-xl mt-2" value={field.value || ""} onChange={field.onChange} data-testid="input-imagen-url" />
                      </FormControl>
                    </FormItem>
                  )} />

                  <FormField control={form.control} name="published" render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-xl border border-border/50 p-4 bg-gray-50">
                      <div>
                        <FormLabel className="text-base">Publicar Curso</FormLabel>
                        <FormDescription>Hacer visible en el catálogo para los estudiantes.</FormDescription>
                      </div>
                      <FormControl><Switch checked={field.value} onCheckedChange={field.onChange} data-testid="switch-publicar" /></FormControl>
                    </FormItem>
                  )} />
                </form>
              </Form>
            </div>

            {!isNew && <LessonManager courseId={courseId} lessons={lessons || []} />}
          </div>

          {/* Sidebar preview */}
          <div>
            <div className="bg-white p-6 rounded-2xl border border-border/50 shadow-sm sticky top-36">
              <h3 className="font-display font-bold text-lg mb-4">Vista previa</h3>
              <div className="aspect-video bg-muted rounded-xl mb-4 overflow-hidden border border-border">
                {form.watch("imageUrl") ? (
                  <img src={form.watch("imageUrl")} alt="Preview" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center text-muted-foreground gap-2">
                    <ImageIcon className="h-8 w-8 opacity-30" /><span className="text-xs">Sin imagen</span>
                  </div>
                )}
              </div>
              <h4 className="font-semibold text-sm mb-1 line-clamp-2">{form.watch("title") || "Título del Curso"}</h4>
              <p className="text-2xl font-display font-bold text-accent">
                {form.watch("priceAmount") > 0 ? `${currencySymbol}${Number(form.watch("priceAmount")).toFixed(2)}` : "Gratis"}
              </p>
              <p className="text-xs text-muted-foreground mt-1">{watchCurrency === "DOP" ? "Pesos Dominicanos" : "Dólares Americanos"}</p>
              {!isNew && (
                <div className="mt-4 pt-4 border-t border-border/50 space-y-1 text-sm text-muted-foreground">
                  <p>{lessons?.length || 0} lección{(lessons?.length || 0) !== 1 ? "es" : ""}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
