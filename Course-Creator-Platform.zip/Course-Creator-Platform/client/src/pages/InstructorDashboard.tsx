import { Link } from "wouter";
import { Navbar } from "@/components/layout/Navbar";
import { useCourses } from "@/hooks/use-courses";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Plus, Users, DollarSign, LayoutDashboard, MoreVertical, Edit, Eye, GraduationCap } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function InstructorDashboard() {
  const { data: courses, isLoading } = useCourses();
  const { isAuthenticated, isLoading: authLoading } = useAuth();

  const formatPrice = (cents: number) => new Intl.NumberFormat('es-DO', {
    style: 'currency',
    currency: 'USD',
  }).format(cents / 100);

  if (!authLoading && !isAuthenticated) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="max-w-lg mx-auto px-4 py-32 text-center">
          <GraduationCap className="h-16 w-16 text-accent mx-auto mb-6" />
          <h1 className="font-display text-3xl font-bold mb-4">Acceso de Instructor</h1>
          <p className="text-muted-foreground mb-8">Debes iniciar sesión para gestionar tus cursos.</p>
          <Button asChild className="bg-accent text-white rounded-full px-8">
            <a href="/api/login">Iniciar sesión</a>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Navbar />

      <div className="bg-white border-b border-border/50 shadow-sm sticky top-16 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-accent/10 rounded-lg">
                <LayoutDashboard className="h-6 w-6 text-accent" />
              </div>
              <h1 className="font-display text-2xl font-bold text-foreground">Panel de Instructor</h1>
            </div>
            <Button asChild className="bg-accent text-white rounded-xl shadow-md" data-testid="button-nuevo-curso">
              <Link href="/instructor/courses/new">
                <Plus className="mr-2 h-4 w-4" /> Crear Nuevo Curso
              </Link>
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-grow w-full">

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
          {[
            { label: "Total Cursos", value: courses?.length || 0, icon: LayoutDashboard, color: "text-blue-500", bg: "bg-blue-500/10" },
            { label: "Estudiantes Activos", value: "---", icon: Users, color: "text-green-500", bg: "bg-green-500/10" },
            { label: "Ingresos Totales", value: "---", icon: DollarSign, color: "text-accent", bg: "bg-accent/10" },
          ].map((stat, i) => (
            <div key={i} className="bg-white rounded-2xl p-6 border border-border/50 shadow-sm flex items-center gap-4">
              <div className={`p-4 rounded-xl ${stat.bg}`}>
                <stat.icon className={`h-7 w-7 ${stat.color}`} />
              </div>
              <div>
                <p className="text-muted-foreground text-sm font-medium">{stat.label}</p>
                <h3 className="font-display text-3xl font-bold text-foreground mt-0.5">{stat.value}</h3>
              </div>
            </div>
          ))}
        </div>

        <h2 className="font-display text-xl font-bold mb-6">Gestionar Cursos</h2>

        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map(i => <Skeleton key={i} className="h-20 w-full rounded-2xl" />)}
          </div>
        ) : courses && courses.length > 0 ? (
          <div className="bg-white rounded-2xl border border-border/50 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="bg-gray-50 text-muted-foreground uppercase text-xs font-semibold">
                  <tr>
                    <th className="px-6 py-4">Nombre del Curso</th>
                    <th className="px-6 py-4">Estado</th>
                    <th className="px-6 py-4">Precio</th>
                    <th className="px-6 py-4 text-right">Acciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/50">
                  {courses.map(course => (
                    <tr key={course.id} className="hover:bg-gray-50 transition-colors group" data-testid={`row-course-${course.id}`}>
                      <td className="px-6 py-4 font-medium text-foreground">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 rounded-lg bg-muted overflow-hidden flex-shrink-0 border border-border/50">
                            {course.imageUrl ? (
                              <img src={course.imageUrl} alt={course.title} className="w-full h-full object-cover" />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center bg-accent/10 text-accent text-xs font-bold">WPS</div>
                            )}
                          </div>
                          <span className="line-clamp-2">{course.title}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <Badge variant={course.published ? "default" : "secondary"} className={course.published ? "bg-green-100 text-green-700 border-none" : "border-none"}>
                          {course.published ? "Publicado" : "Borrador"}
                        </Badge>
                      </td>
                      <td className="px-6 py-4 text-muted-foreground font-medium">
                        {course.price === 0 ? "Gratis" : formatPrice(course.price)}
                      </td>
                      <td className="px-6 py-4 text-right">
                        <Button variant="ghost" size="sm" asChild className="mr-2 hidden sm:inline-flex" data-testid={`button-editar-${course.id}`}>
                          <Link href={`/instructor/courses/${course.id}/edit`}>
                            <Edit className="h-4 w-4 mr-1" /> Editar
                          </Link>
                        </Button>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-44">
                            <DropdownMenuItem asChild>
                              <Link href={`/instructor/courses/${course.id}/edit`} className="cursor-pointer">
                                <Edit className="h-4 w-4 mr-2" /> Editar curso
                              </Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem asChild>
                              <Link href={`/courses/${course.id}`} className="cursor-pointer">
                                <Eye className="h-4 w-4 mr-2" /> Ver página pública
                              </Link>
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          <div className="text-center py-20 bg-white rounded-2xl border border-border/50 shadow-sm max-w-2xl mx-auto">
            <div className="bg-accent/10 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Plus className="h-10 w-10 text-accent" />
            </div>
            <h3 className="text-xl font-display font-semibold text-foreground mb-2">Crea tu primer curso</h3>
            <p className="text-muted-foreground mb-8">Comparte tu experiencia y comienza a monetizar tu conocimiento hoy.</p>
            <Button asChild size="lg" className="bg-accent text-white rounded-xl">
              <Link href="/instructor/courses/new">Crear Curso</Link>
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
