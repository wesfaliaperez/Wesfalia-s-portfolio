import { useState, useEffect, useRef } from "react";
import { useParams, Link } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useCourse } from "@/hooks/use-courses";
import { useLessons } from "@/hooks/use-lessons";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  ChevronLeft, PlayCircle, FileText, Menu, X, Download, CheckCircle,
  FileSpreadsheet, Presentation, File, BookOpen, AlertCircle, Trophy,
  ChevronRight, CheckSquare
} from "lucide-react";
import { cn } from "@/lib/utils";

function fileIcon(type: string) {
  if (type === "pdf") return <FileText className="h-5 w-5 text-red-500" />;
  if (type === "excel" || type === "xlsx" || type === "xls" || type === "csv") return <FileSpreadsheet className="h-5 w-5 text-green-600" />;
  if (type === "pptx" || type === "ppt") return <Presentation className="h-5 w-5 text-orange-500" />;
  if (type === "docx" || type === "doc") return <FileText className="h-5 w-5 text-blue-600" />;
  if (type === "link") return <BookOpen className="h-5 w-5 text-purple-500" />;
  return <File className="h-5 w-5 text-muted-foreground" />;
}

function fileSizeLabel(bytes?: number | null) {
  if (!bytes) return "";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function QuizComponent({ quiz, lessonId }: { quiz: any; lessonId: number }) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [submitted, setSubmitted] = useState(false);
  const [result, setResult] = useState<{ score: number; passed: boolean; correct: number; total: number; passingScore: number } | null>(null);

  const { data: bestAttempt } = useQuery({
    queryKey: ["/api/quizzes", quiz.id, "my-attempt"],
    queryFn: async () => {
      const r = await fetch(`/api/quizzes/${quiz.id}/my-attempt`, { credentials: "include" });
      return r.ok ? r.json() : null;
    }
  });

  const submitMutation = useMutation({
    mutationFn: async (answers: number[]) => {
      const r = await apiRequest("POST", `/api/quizzes/${quiz.id}/submit`, { answers });
      return r.json();
    },
    onSuccess: (data) => {
      setResult(data);
      setSubmitted(true);
      queryClient.invalidateQueries({ queryKey: ["/api/quizzes", quiz.id, "my-attempt"] });
    },
    onError: () => toast({ title: "Error", description: "No se pudo enviar el quiz.", variant: "destructive" })
  });

  const handleSubmit = () => {
    const answers = quiz.questions.map((_: any, i: number) => selectedAnswers[i] ?? -1);
    submitMutation.mutate(answers);
  };

  const handleRetry = () => {
    setSelectedAnswers({});
    setSubmitted(false);
    setResult(null);
  };

  if (!quiz.questions || quiz.questions.length === 0) {
    return (
      <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4 flex items-center gap-3 text-sm text-yellow-800">
        <AlertCircle className="h-5 w-5 text-yellow-600 shrink-0" />
        El instructor aún no ha agregado preguntas a este quiz.
      </div>
    );
  }

  if (submitted && result) {
    return (
      <div className={cn("rounded-xl border p-6 text-center", result.passed ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200")}>
        {result.passed ? (
          <Trophy className="h-12 w-12 text-green-500 mx-auto mb-3" />
        ) : (
          <AlertCircle className="h-12 w-12 text-red-400 mx-auto mb-3" />
        )}
        <h3 className="font-display font-bold text-2xl mb-1">{result.score}%</h3>
        <p className={cn("font-semibold text-lg mb-2", result.passed ? "text-green-700" : "text-red-700")}>
          {result.passed ? "¡Felicitaciones! Aprobaste." : "No aprobaste esta vez."}
        </p>
        <p className="text-muted-foreground text-sm mb-4">
          {result.correct} de {result.total} respuestas correctas · Mínimo para aprobar: {result.passingScore}%
        </p>
        {!result.passed && (
          <Button variant="outline" onClick={handleRetry} className="rounded-xl">
            Intentar de nuevo
          </Button>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {bestAttempt && (
        <div className={cn("text-sm rounded-xl px-4 py-3 flex items-center gap-2", bestAttempt.passed ? "bg-green-50 border border-green-200 text-green-800" : "bg-amber-50 border border-amber-200 text-amber-800")}>
          {bestAttempt.passed ? <CheckCircle className="h-4 w-4 shrink-0" /> : <AlertCircle className="h-4 w-4 shrink-0" />}
          Mejor intento: <strong>{bestAttempt.score}%</strong> — {bestAttempt.passed ? "Aprobado" : "No aprobado"}. Puedes intentar de nuevo.
        </div>
      )}

      <div className="bg-accent/5 border border-accent/20 rounded-xl p-4 flex items-center justify-between">
        <div>
          <h4 className="font-semibold">{quiz.title}</h4>
          <p className="text-sm text-muted-foreground">{quiz.questions.length} preguntas · Mínimo para aprobar: {quiz.passingScore}%</p>
        </div>
        <Badge variant="outline" className="border-accent text-accent">Evaluación</Badge>
      </div>

      {quiz.questions.map((q: any, idx: number) => (
        <div key={q.id} className="border border-border rounded-xl p-5">
          <p className="font-medium mb-4 flex gap-2">
            <span className="bg-accent text-white rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold shrink-0">{idx + 1}</span>
            {q.question}
          </p>
          <div className="space-y-2">
            {q.options.map((option: string, oi: number) => (
              <button
                key={oi}
                onClick={() => setSelectedAnswers(prev => ({ ...prev, [idx]: oi }))}
                className={cn(
                  "w-full text-left px-4 py-3 rounded-lg border transition-all text-sm",
                  selectedAnswers[idx] === oi
                    ? "bg-accent text-white border-accent"
                    : "border-border hover:bg-muted hover:border-accent/30"
                )}
              >
                <span className="font-mono text-xs mr-2 opacity-60">{String.fromCharCode(65 + oi)}.</span>
                {option}
              </button>
            ))}
          </div>
          {q.explanation && selectedAnswers[idx] !== undefined && (
            <p className="mt-3 text-xs text-muted-foreground bg-muted/50 rounded-lg p-3 italic">{q.explanation}</p>
          )}
        </div>
      ))}

      <Button
        className="w-full bg-accent text-white rounded-xl h-12 font-semibold"
        onClick={handleSubmit}
        disabled={submitMutation.isPending || Object.keys(selectedAnswers).length < quiz.questions.length}
        data-testid="button-submit-quiz"
      >
        {submitMutation.isPending ? "Enviando..." : `Enviar respuestas (${Object.keys(selectedAnswers).length}/${quiz.questions.length})`}
      </Button>
    </div>
  );
}

export default function LessonPlayer() {
  const { id } = useParams();
  const courseId = Number(id);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: course, isLoading: isCourseLoading } = useCourse(courseId);
  const { data: lessons, isLoading: isLessonsLoading } = useLessons(courseId);

  const [activeLessonId, setActiveLessonId] = useState<number | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [activeTab, setActiveTab] = useState<"video" | "materials" | "quiz">("video");

  const { data: progress } = useQuery({
    queryKey: ["/api/courses", courseId, "progress"],
    queryFn: async () => {
      const r = await fetch(`/api/courses/${courseId}/progress`, { credentials: "include" });
      return r.ok ? r.json() : { completedLessonIds: [] };
    }
  });

  const completedIds: number[] = progress?.completedLessonIds || [];

  const completeMutation = useMutation({
    mutationFn: async (lessonId: number) => {
      await apiRequest("POST", `/api/lessons/${lessonId}/complete`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/courses", courseId, "progress"] });
      toast({ title: "¡Lección completada!", description: "Has marcado esta lección como completada." });
    }
  });

  useEffect(() => {
    if (lessons && lessons.length > 0 && !activeLessonId) {
      const sorted = [...lessons].sort((a, b) => a.order - b.order);
      setActiveLessonId(sorted[0].id);
    }
  }, [lessons, activeLessonId]);

  useEffect(() => {
    setActiveTab("video");
  }, [activeLessonId]);

  const activeLesson = lessons?.find((l: any) => l.id === activeLessonId) as any;

  if (isCourseLoading || isLessonsLoading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center text-white">
        <div className="text-center">
          <PlayCircle className="h-16 w-16 text-accent mx-auto mb-4 animate-pulse" />
          <p className="text-lg text-white/70">Cargando reproductor...</p>
        </div>
      </div>
    );
  }

  if (!course) return <div className="p-8 text-center">Curso no encontrado</div>;

  const sortedLessons = lessons ? [...lessons].sort((a: any, b: any) => a.order - b.order) : [];
  const completionPct = sortedLessons.length > 0 ? Math.round((completedIds.length / sortedLessons.length) * 100) : 0;
  const activeLessonIdx = sortedLessons.findIndex((l: any) => l.id === activeLessonId);

  const materials = activeLesson?.materials || [];
  const quiz = activeLesson?.quiz;
  const hasMaterials = materials.length > 0;
  const hasQuiz = !!quiz;

  return (
    <div className="h-screen flex flex-col bg-background overflow-hidden">
      {/* Header */}
      <header className="h-16 bg-gray-900 text-white flex items-center justify-between px-4 shrink-0 z-20">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" className="text-white rounded-full" asChild>
            <Link href="/dashboard"><ChevronLeft className="h-6 w-6" /></Link>
          </Button>
          <div className="hidden sm:block">
            <h1 className="font-display font-semibold text-base line-clamp-1">{course.title}</h1>
          </div>
        </div>
        <div className="flex items-center gap-4">
          {completionPct > 0 && (
            <div className="hidden md:flex items-center gap-3">
              <Progress value={completionPct} className="w-24 h-2 bg-white/20" />
              <span className="text-xs text-white/70">{completionPct}% completado</span>
            </div>
          )}
          <img
            src="https://wpsconsultingroup.com/img/fondo.png"
            alt="WPS"
            className="h-7 object-contain brightness-0 invert opacity-70 hidden md:block"
          />
          <Button
            variant="ghost"
            className="text-white lg:hidden"
            onClick={() => setSidebarOpen(!sidebarOpen)}
          >
            {sidebarOpen ? <X className="h-5 w-5 mr-2" /> : <Menu className="h-5 w-5 mr-2" />}
            {sidebarOpen ? "Cerrar" : "Contenido"}
          </Button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden relative">
        {/* Main Content Area */}
        <main className="flex-1 flex flex-col overflow-y-auto">
          {activeLesson ? (
            <div className="w-full max-w-5xl mx-auto flex flex-col">

              {/* Video */}
              <div className="w-full bg-black aspect-video flex-shrink-0">
                {activeLesson.videoUrl ? (
                  <video
                    key={activeLesson.id}
                    src={activeLesson.videoUrl}
                    controls
                    className="w-full h-full object-contain"
                    controlsList="nodownload"
                    autoPlay
                  />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center text-white/50">
                    <PlayCircle className="w-20 h-20 mb-4 opacity-40" />
                    <p className="text-lg font-medium">Sin video</p>
                    <p className="text-sm text-white/30 mt-2">Revisa el contenido textual y los materiales de esta lección</p>
                  </div>
                )}
              </div>

              {/* Content tabs */}
              <div className="bg-white border-x border-border/30 flex-1">
                {/* Tab bar */}
                <div className="flex border-b border-border/30 px-6 gap-1">
                  <button
                    onClick={() => setActiveTab("video")}
                    className={cn("py-4 px-3 text-sm font-medium border-b-2 transition-colors -mb-px", activeTab === "video" ? "border-accent text-accent" : "border-transparent text-muted-foreground hover:text-foreground")}
                    data-testid="tab-contenido"
                  >
                    <FileText className="h-4 w-4 inline mr-1.5" />
                    Contenido
                  </button>
                  {hasMaterials && (
                    <button
                      onClick={() => setActiveTab("materials")}
                      className={cn("py-4 px-3 text-sm font-medium border-b-2 transition-colors -mb-px flex items-center gap-1.5", activeTab === "materials" ? "border-accent text-accent" : "border-transparent text-muted-foreground hover:text-foreground")}
                      data-testid="tab-materiales"
                    >
                      <Download className="h-4 w-4" />
                      Materiales
                      <span className="bg-accent/10 text-accent text-xs rounded-full px-1.5">{materials.length}</span>
                    </button>
                  )}
                  {hasQuiz && (
                    <button
                      onClick={() => setActiveTab("quiz")}
                      className={cn("py-4 px-3 text-sm font-medium border-b-2 transition-colors -mb-px flex items-center gap-1.5", activeTab === "quiz" ? "border-accent text-accent" : "border-transparent text-muted-foreground hover:text-foreground")}
                      data-testid="tab-quiz"
                    >
                      <CheckSquare className="h-4 w-4" />
                      Evaluación
                    </button>
                  )}
                </div>

                {/* Tab content */}
                <div className="p-6 md:p-8">
                  {activeTab === "video" && (
                    <>
                      <p className="text-sm text-accent font-semibold mb-2 uppercase tracking-wide">
                        Lección {activeLessonIdx + 1} de {sortedLessons.length}
                      </p>
                      <h2 className="font-display text-2xl md:text-3xl font-bold mb-4">{activeLesson.title}</h2>
                      {activeLesson.description && (
                        <div className="prose prose-slate max-w-none text-muted-foreground leading-relaxed whitespace-pre-wrap">
                          <p>{activeLesson.description}</p>
                        </div>
                      )}
                    </>
                  )}

                  {activeTab === "materials" && (
                    <div className="space-y-4">
                      <h3 className="font-display font-bold text-lg">Materiales de esta Lección</h3>
                      {materials.map((mat: any) => (
                        <div key={mat.id} className="flex items-center gap-4 p-4 border border-border rounded-xl hover:bg-muted/30 transition-colors">
                          <div className="shrink-0">{fileIcon(mat.type)}</div>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-sm truncate">{mat.title}</p>
                            <p className="text-xs text-muted-foreground uppercase mt-0.5">
                              {mat.type.toUpperCase()}
                              {mat.fileSize ? ` · ${fileSizeLabel(mat.fileSize)}` : ""}
                            </p>
                          </div>
                          {mat.textContent ? (
                            <details className="text-sm">
                              <summary className="cursor-pointer text-accent font-medium">Ver contenido</summary>
                              <div className="mt-2 p-3 bg-muted rounded-lg whitespace-pre-wrap text-xs text-muted-foreground max-h-48 overflow-y-auto">{mat.textContent}</div>
                            </details>
                          ) : mat.fileUrl ? (
                            <a
                              href={mat.fileUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              download
                              data-testid={`button-download-${mat.id}`}
                            >
                              <Button variant="outline" size="sm" className="rounded-lg shrink-0">
                                <Download className="h-4 w-4 mr-1" /> Descargar
                              </Button>
                            </a>
                          ) : null}
                        </div>
                      ))}
                    </div>
                  )}

                  {activeTab === "quiz" && quiz && (
                    <div className="space-y-4">
                      <QuizComponent quiz={quiz} lessonId={activeLesson.id} />
                    </div>
                  )}

                  {/* Navigation */}
                  <div className="flex gap-3 mt-8 pt-6 border-t border-border/30 flex-wrap">
                    {!completedIds.includes(activeLesson.id) && (
                      <Button
                        variant="outline"
                        className="rounded-xl border-green-300 text-green-700 hover:bg-green-50"
                        onClick={() => completeMutation.mutate(activeLesson.id)}
                        disabled={completeMutation.isPending}
                        data-testid="button-marcar-completada"
                      >
                        <CheckCircle className="h-4 w-4 mr-2" />
                        {completeMutation.isPending ? "Guardando..." : "Marcar como completada"}
                      </Button>
                    )}
                    {completedIds.includes(activeLesson.id) && (
                      <div className="flex items-center gap-2 text-green-600 text-sm font-medium">
                        <CheckCircle className="h-4 w-4" /> Lección completada
                      </div>
                    )}
                    <div className="flex gap-3 ml-auto">
                      {activeLessonIdx > 0 && (
                        <Button
                          variant="outline"
                          className="rounded-xl"
                          onClick={() => setActiveLessonId((sortedLessons[activeLessonIdx - 1] as any).id)}
                        >
                          <ChevronLeft className="h-4 w-4 mr-1" /> Anterior
                        </Button>
                      )}
                      {activeLessonIdx < sortedLessons.length - 1 && (
                        <Button
                          className="bg-accent text-white rounded-xl"
                          onClick={() => setActiveLessonId((sortedLessons[activeLessonIdx + 1] as any).id)}
                          data-testid="button-siguiente"
                        >
                          Siguiente <ChevronRight className="h-4 w-4 ml-1" />
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex-1 flex items-center justify-center text-muted-foreground">
              <div className="text-center">
                <PlayCircle className="h-16 w-16 text-accent mx-auto mb-4 opacity-50" />
                <p>Selecciona una lección para comenzar</p>
              </div>
            </div>
          )}
        </main>

        {/* Sidebar */}
        <aside
          className={cn(
            "bg-white border-l border-border/50 w-full lg:w-80 flex-shrink-0 flex flex-col absolute inset-y-0 right-0 z-10 transition-transform duration-300 ease-in-out lg:relative lg:translate-x-0 shadow-2xl lg:shadow-none",
            sidebarOpen ? "translate-x-0" : "translate-x-full"
          )}
        >
          <div className="p-4 border-b border-border/50 bg-gray-50">
            <h3 className="font-display font-semibold text-base text-foreground">Contenido del Curso</h3>
            <div className="flex items-center gap-2 mt-1">
              <Progress value={completionPct} className="flex-1 h-1.5" />
              <span className="text-xs text-muted-foreground shrink-0">{completionPct}%</span>
            </div>
          </div>

          <ScrollArea className="flex-1">
            <div className="p-2 space-y-1">
              {sortedLessons.map((lesson: any, idx: number) => {
                const isActive = lesson.id === activeLessonId;
                const isCompleted = completedIds.includes(lesson.id);
                const hasQuizBadge = !!lesson.quiz;
                const matCount = lesson.materials?.length || 0;
                return (
                  <button
                    key={lesson.id}
                    onClick={() => {
                      setActiveLessonId(lesson.id);
                      if (window.innerWidth < 1024) setSidebarOpen(false);
                    }}
                    className={cn(
                      "w-full text-left p-4 rounded-xl transition-all flex items-start gap-3 group",
                      isActive
                        ? "bg-accent/10 border border-accent/20"
                        : "hover:bg-gray-50 border border-transparent"
                    )}
                    data-testid={`button-lesson-${lesson.id}`}
                  >
                    <div className="mt-0.5 shrink-0">
                      {isCompleted ? (
                        <CheckCircle className="w-5 h-5 text-green-500" />
                      ) : isActive ? (
                        <PlayCircle className="w-5 h-5 text-accent" />
                      ) : (
                        <div className="w-5 h-5 rounded-full border-2 border-muted-foreground/30 flex items-center justify-center text-[10px] font-medium text-muted-foreground">
                          {idx + 1}
                        </div>
                      )}
                    </div>
                    <div className="flex flex-col flex-1 min-w-0">
                      <span className={cn(
                        "font-medium text-sm leading-tight mb-1 truncate",
                        isActive ? "text-foreground font-semibold" : "text-muted-foreground group-hover:text-foreground"
                      )}>
                        {lesson.title}
                      </span>
                      <div className="flex items-center gap-1 flex-wrap">
                        {lesson.videoUrl && <span className="text-xs text-muted-foreground flex items-center gap-0.5"><PlayCircle className="w-3 h-3" /> Video</span>}
                        {matCount > 0 && <span className="text-xs text-muted-foreground flex items-center gap-0.5"><Download className="w-3 h-3" /> {matCount} archivos</span>}
                        {hasQuizBadge && <span className="text-xs bg-accent/10 text-accent rounded px-1">Quiz</span>}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </ScrollArea>
        </aside>
      </div>
    </div>
  );
}
