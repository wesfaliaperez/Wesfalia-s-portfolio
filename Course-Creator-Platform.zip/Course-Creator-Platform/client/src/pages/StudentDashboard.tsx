import { Link } from "wouter";
import { Navbar } from "@/components/layout/Navbar";
import { usePurchases } from "@/hooks/use-purchases";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { BookOpen, GraduationCap, PlayCircle, ChevronRight } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function StudentDashboard() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const { data: purchases, isLoading } = usePurchases();

  if (authLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="max-w-7xl mx-auto px-4 py-12">
          <Skeleton className="h-12 w-48 mb-8" />
          <div className="grid md:grid-cols-3 gap-6">
            {[1, 2].map(i => <Skeleton key={i} className="h-48 rounded-2xl" />)}
          </div>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="max-w-lg mx-auto px-4 py-32 text-center">
          <GraduationCap className="h-16 w-16 text-accent mx-auto mb-6 opacity-80" />
          <h1 className="font-display text-3xl font-bold mb-4">Inicia sesión para ver tus cursos</h1>
          <p className="text-muted-foreground mb-8">Accede a tu cuenta para ver el progreso de tu aprendizaje.</p>
          <Button asChild className="bg-accent text-white rounded-full px-8">
            <a href="/api/login">Iniciar sesión</a>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Navbar />

      <div className="bg-white border-b border-border/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center gap-4">
            <div className="bg-accent/10 p-3 rounded-xl">
              <GraduationCap className="h-7 w-7 text-accent" />
            </div>
            <div>
              <h1 className="font-display text-2xl font-bold text-foreground">Mi Aprendizaje</h1>
              <p className="text-muted-foreground text-sm">
                {user?.firstName ? `¡Hola, ${user.firstName}! Continúa donde lo dejaste.` : "Continúa donde lo dejaste."}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-grow w-full">
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map(i => <Skeleton key={i} className="h-56 rounded-2xl" />)}
          </div>
        ) : purchases && purchases.length > 0 ? (
          <>
            <h2 className="font-display text-xl font-bold mb-6 text-foreground">
              Mis Cursos ({purchases.length})
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {purchases.map(purchase => {
                const course = purchase.course;
                if (!course) return null;
                return (
                  <div
                    key={purchase.id}
                    className="bg-white rounded-2xl border border-border/50 shadow-sm overflow-hidden group"
                    data-testid={`card-course-${course.id}`}
                  >
                    <div className="relative h-40 bg-muted overflow-hidden">
                      {course.imageUrl && (
                        <img
                          src={course.imageUrl}
                          alt={course.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      )}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent flex items-end p-4">
                        <div className="w-8 h-8 rounded-full bg-accent flex items-center justify-center shadow-lg">
                          <PlayCircle className="h-4 w-4 text-white" />
                        </div>
                      </div>
                    </div>
                    <div className="p-5">
                      <h3 className="font-display font-bold text-foreground line-clamp-2 mb-1 text-base leading-snug">
                        {course.title}
                      </h3>
                      <p className="text-xs text-muted-foreground mb-4 line-clamp-2">
                        {course.description}
                      </p>
                      <Button asChild className="w-full bg-accent text-white rounded-xl h-10 text-sm font-semibold" data-testid={`button-continuar-${course.id}`}>
                        <Link href={`/dashboard/courses/${course.id}/learn`}>
                          Continuar <ChevronRight className="ml-1 h-4 w-4" />
                        </Link>
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        ) : (
          <div className="text-center py-24 max-w-lg mx-auto">
            <div className="bg-accent/10 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6">
              <BookOpen className="h-12 w-12 text-accent" />
            </div>
            <h2 className="font-display text-2xl font-bold text-foreground mb-3">Aún no tienes cursos</h2>
            <p className="text-muted-foreground mb-8 leading-relaxed">
              Explora nuestro catálogo y comienza tu camino de aprendizaje con WPS Consulting Group.
            </p>
            <Button asChild size="lg" className="bg-accent text-white rounded-full px-8">
              <Link href="/#cursos">Explorar Cursos</Link>
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
