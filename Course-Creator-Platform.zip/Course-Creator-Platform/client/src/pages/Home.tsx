import { Link } from "wouter";
import { Navbar } from "@/components/layout/Navbar";
import { useCourses } from "@/hooks/use-courses";
import { CourseCard } from "@/components/ui/course-card";
import { Button } from "@/components/ui/button";
import { ArrowRight, BookOpen, Award, TrendingUp, Users } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function Home() {
  const { data: courses, isLoading } = useCourses();
  const publishedCourses = courses?.filter(c => c.published) || [];

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative pt-20 pb-32 overflow-hidden bg-white">
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 rounded-full bg-accent/10 blur-3xl opacity-50 pointer-events-none" />
        <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-80 h-80 rounded-full bg-primary/10 blur-3xl opacity-50 pointer-events-none" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="max-w-2xl">
              <div className="inline-flex items-center rounded-full border border-accent/30 bg-accent/5 px-3 py-1 text-sm font-medium text-accent mb-6">
                <span className="flex h-2 w-2 rounded-full bg-accent mr-2"></span>
                WPS Consulting Group Academia
              </div>
              <h1 className="font-display text-5xl md:text-6xl lg:text-7xl font-extrabold tracking-tight text-foreground mb-6 leading-[1.1]">
                Convertimos <span className="text-accent">Datos</span> en Conocimiento Accionable
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground mb-8 leading-relaxed">
                Potencia tus habilidades profesionales con cursos liderados por expertos en analítica de datos, inteligencia artificial y business intelligence.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="bg-accent text-white rounded-full h-14 px-8 text-lg shadow-lg shadow-accent/25 transition-all" asChild>
                  <a href="#cursos">
                    Ver Cursos <ArrowRight className="ml-2 h-5 w-5" />
                  </a>
                </Button>
                <Button size="lg" variant="outline" className="rounded-full h-14 px-8 text-lg border-2" asChild>
                  <a href="https://wpsconsultingroup.com" target="_blank" rel="noopener noreferrer">
                    Conocer WPS
                  </a>
                </Button>
              </div>
            </div>
            
            <div className="relative hidden lg:block">
              <img 
                src="https://images.unsplash.com/photo-1552664730-d307ca884978?w=800&q=80" 
                alt="Profesionales en reunión" 
                className="rounded-3xl shadow-2xl object-cover h-[500px] w-full border border-border/50"
              />
              <div className="absolute -bottom-8 -left-8 bg-card p-6 rounded-2xl shadow-xl border border-border/50 max-w-xs">
                <div className="flex items-center gap-4 mb-2">
                  <div className="bg-accent/20 p-3 rounded-xl">
                    <TrendingUp className="h-6 w-6 text-accent" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground font-medium">Tasa de Éxito</p>
                    <p className="font-display font-bold text-2xl text-foreground">98.5%</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-50 border-y border-border/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { icon: BookOpen, title: "Currículo Experto", desc: "Cursos diseñados por profesionales con amplia experiencia en la industria." },
              { icon: Award, title: "Certificación", desc: "Obtén certificados verificables al completar cada programa de formación." },
              { icon: Users, title: "Crecimiento Profesional", desc: "Adquiere habilidades prácticas aplicables inmediatamente en tu trabajo." }
            ].map((feature, i) => (
              <div key={i} className="flex flex-col items-center text-center p-6">
                <div className="bg-accent/10 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                  <feature.icon className="h-8 w-8 text-accent" />
                </div>
                <h3 className="font-display font-bold text-xl mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Courses Section */}
      <section id="cursos" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-end mb-12">
            <div>
              <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-4">Cursos Disponibles</h2>
              <p className="text-muted-foreground text-lg max-w-2xl">
                Descubre nuestros programas más populares y comienza tu camino de aprendizaje hoy.
              </p>
            </div>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1, 2, 3].map(i => (
                <div key={i} className="flex flex-col space-y-4">
                  <Skeleton className="h-48 w-full rounded-2xl" />
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-6 w-full" />
                  <Skeleton className="h-4 w-full" />
                  <div className="flex justify-between pt-4 mt-auto">
                    <Skeleton className="h-4 w-20" />
                    <Skeleton className="h-6 w-16" />
                  </div>
                </div>
              ))}
            </div>
          ) : publishedCourses.length === 0 ? (
            <div className="text-center py-20 bg-secondary/30 rounded-3xl border border-border border-dashed">
              <BookOpen className="mx-auto h-12 w-12 text-muted-foreground mb-4 opacity-50" />
              <h3 className="text-xl font-display font-semibold text-foreground mb-2">Aún no hay cursos disponibles</h3>
              <p className="text-muted-foreground">Pronto publicaremos nuevo contenido de WPS Consulting Group.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {publishedCourses.map(course => (
                <CourseCard key={course.id} course={course} />
              ))}
            </div>
          )}
        </div>
      </section>
      
      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8 mb-10">
            <div>
              <img 
                src="https://wpsconsultingroup.com/img/fondo.png" 
                alt="WPS Consulting Group" 
                className="h-12 object-contain mb-4 brightness-0 invert opacity-80"
              />
              <p className="text-white/60 text-sm leading-relaxed">
                Soluciones personalizadas en analítica de datos, inteligencia artificial y business intelligence.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4 text-white/90">Academia</h4>
              <ul className="space-y-2 text-white/60 text-sm">
                <li><a href="#cursos" className="hover:text-white transition-colors">Todos los Cursos</a></li>
                <li><Link href="/dashboard" className="hover:text-white transition-colors">Mi Aprendizaje</Link></li>
                <li><Link href="/instructor" className="hover:text-white transition-colors">Panel de Instructor</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4 text-white/90">Empresa</h4>
              <ul className="space-y-2 text-white/60 text-sm">
                <li><a href="https://wpsconsultingroup.com" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">Sitio Web Principal</a></li>
                <li><a href="https://wpsconsultingroup.com/#servicios" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">Servicios</a></li>
                <li><a href="https://wpsconsultingroup.com/#contacto" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">Contacto</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-white/10 pt-8 text-center text-sm text-white/40">
            &copy; {new Date().getFullYear()} WPS Consulting Group. Todos los derechos reservados.
          </div>
        </div>
      </footer>
    </div>
  );
}
