import { Link } from "wouter";
import { type CourseResponse } from "@shared/schema";
import { PlayCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface CourseCardProps {
  course: CourseResponse;
  isPurchased?: boolean;
  progress?: number;
}

export function CourseCard({ course, isPurchased = false, progress = 0 }: CourseCardProps) {
  const currency = (course as any).currency || "USD";
  const formattedPrice = new Intl.NumberFormat('es-DO', {
    style: 'currency',
    currency,
  }).format(course.price / 100);

  const fallbackImage = `https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=800&q=80`;
  const targetUrl = isPurchased ? `/dashboard/courses/${course.id}/learn` : `/courses/${course.id}`;

  return (
    <Link href={targetUrl} className="block group h-full" data-testid={`card-course-${course.id}`}>
      <div className="bg-card rounded-2xl overflow-hidden border border-border/50 hover-elevate h-full flex flex-col shadow-sm">
        <div className="relative aspect-video overflow-hidden bg-muted">
          <img
            src={course.imageUrl || fallbackImage}
            alt={course.title}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
          {isPurchased && (
            <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              <PlayCircle className="w-16 h-16 text-white opacity-80" />
            </div>
          )}
          {!course.published && !isPurchased && (
            <Badge className="absolute top-3 left-3 bg-secondary text-secondary-foreground border-none">Borrador</Badge>
          )}
        </div>

        <div className="p-5 flex flex-col flex-grow">
          <div className="flex items-center gap-2 mb-3">
            <Badge variant="outline" className="text-xs font-normal border-accent/20 text-accent">
              Consultoría
            </Badge>
          </div>

          <h3 className="font-display font-bold text-base leading-tight mb-2 text-foreground group-hover:text-accent transition-colors line-clamp-2">
            {course.title}
          </h3>

          <p className="text-sm text-muted-foreground line-clamp-2 mb-4 flex-grow">
            {course.description}
          </p>

          <div className="mt-auto pt-4 border-t border-border/50 flex items-center justify-between gap-2">
            {isPurchased ? (
              <div className="w-full">
                <div className="flex justify-between text-xs mb-1.5">
                  <span className="font-medium text-foreground">Progreso</span>
                  <span className="text-muted-foreground">{progress}%</span>
                </div>
                <div className="w-full bg-secondary h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-accent h-full rounded-full transition-all duration-500"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>
            ) : (
              <>
                <div className="flex items-center text-sm text-muted-foreground font-medium truncate">
                  {course.instructor?.firstName
                    ? `${course.instructor.firstName} ${course.instructor.lastName}`
                    : "WPS Experto"}
                </div>
                <div className="font-display font-bold text-lg text-foreground shrink-0">
                  {course.price === 0 ? "Gratis" : formattedPrice}
                  {currency === "DOP" && course.price > 0 && <span className="text-xs font-normal text-muted-foreground ml-1">DOP</span>}
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </Link>
  );
}
