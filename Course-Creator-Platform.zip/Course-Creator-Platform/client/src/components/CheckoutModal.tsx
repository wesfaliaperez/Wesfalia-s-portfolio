import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, CreditCard, ShieldCheck } from "lucide-react";
import PayPalButton from "@/components/PayPalButton";
import { useToast } from "@/hooks/use-toast";

const DOP_RATE = 58; // approximate USD→DOP conversion rate

interface CheckoutModalProps {
  open: boolean;
  onClose: () => void;
  course: { id: number; title: string; price: number; currency?: string };
  onPaymentSuccess: () => void;
}

export function CheckoutModal({ open, onClose, course, onPaymentSuccess }: CheckoutModalProps) {
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);
  const [cardNumber, setCardNumber] = useState("");
  const [expiry, setExpiry] = useState("");
  const [cvv, setCvv] = useState("");
  const [cardName, setCardName] = useState("");

  const currency = course.currency || "USD";
  const priceInUnits = course.price / 100;

  // For Azul (DOP-based gateway)
  const azulAmountDOP = currency === "DOP" ? priceInUnits : priceInUnits * DOP_RATE;
  const itbisDOP = azulAmountDOP * 0.18;
  const azulTotalDOP = azulAmountDOP + itbisDOP;

  // For PayPal (USD only)
  const paypalAmountUSD = currency === "USD" ? priceInUnits : priceInUnits / DOP_RATE;
  const priceUSD = paypalAmountUSD.toFixed(2);

  const isPayPalAvailable = currency === "USD";

  const formatCardNumber = (val: string) =>
    val.replace(/\D/g, "").replace(/(.{4})/g, "$1 ").trim().substring(0, 19);

  const formatExpiry = (val: string) => {
    const cleaned = val.replace(/\D/g, "");
    if (cleaned.length >= 3) return cleaned.substring(0, 2) + "/" + cleaned.substring(2, 4);
    return cleaned;
  };

  const handleAzulPayment = async () => {
    if (!cardNumber || !expiry || !cvv || !cardName) {
      toast({ title: "Datos incompletos", description: "Por favor complete todos los campos.", variant: "destructive" });
      return;
    }

    setIsProcessing(true);
    try {
      const expiryClean = expiry.replace("/", "");
      const amountCents = Math.round(azulAmountDOP * 100);
      const itbisCents = Math.round(itbisDOP * 100);

      const response = await fetch("/api/azul/charge", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          cardNumber: cardNumber.replace(/\s+/g, ""),
          expiry: expiryClean,
          cvv,
          amount: amountCents,
          itbis: itbisCents,
          orderId: `COURSE-${course.id}-${Date.now()}`,
          customerName: cardName,
          courseId: course.id,
        }),
      });

      const data = await response.json();
      if (data.success) {
        toast({ title: "¡Pago exitoso!", description: "Ya puedes acceder al curso." });
        onPaymentSuccess();
        onClose();
      } else {
        toast({ title: "Pago rechazado", description: data.error || "Verifica tus datos.", variant: "destructive" });
      }
    } catch {
      toast({ title: "Error", description: "No se pudo procesar el pago.", variant: "destructive" });
    } finally {
      setIsProcessing(false);
    }
  };

  const displayPrice = currency === "DOP"
    ? `RD$${priceInUnits.toFixed(2)}`
    : `$${priceInUnits.toFixed(2)} USD`;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[480px] p-0 overflow-hidden rounded-2xl">
        <DialogHeader className="px-6 pt-6 pb-4 border-b border-border/50 bg-gradient-to-r from-accent/5 to-accent/10">
          <DialogTitle className="text-xl font-display font-bold">Completar compra</DialogTitle>
          <div className="mt-2">
            <p className="text-sm text-muted-foreground font-medium line-clamp-1">{course.title}</p>
            <p className="text-2xl font-display font-bold text-accent mt-1">{displayPrice}</p>
          </div>
        </DialogHeader>

        <div className="p-6">
          <Tabs defaultValue="azul">
            <TabsList className={`w-full grid mb-6 h-11 rounded-xl ${isPayPalAvailable ? "grid-cols-2" : "grid-cols-1"}`}>
              <TabsTrigger value="azul" className="rounded-lg text-sm font-medium" data-testid="tab-azul">
                <CreditCard className="h-4 w-4 mr-2" />
                Azul / Tarjeta
              </TabsTrigger>
              {isPayPalAvailable && (
                <TabsTrigger value="paypal" className="rounded-lg text-sm font-medium" data-testid="tab-paypal">
                  <img src="https://www.paypalobjects.com/webstatic/icon/pp16.png" alt="PayPal" className="h-4 w-4 mr-2" />
                  PayPal
                </TabsTrigger>
              )}
            </TabsList>

            {/* Azul Tab */}
            <TabsContent value="azul" className="space-y-4 mt-0">
              <div className="flex items-center gap-2 text-xs text-muted-foreground bg-green-50 border border-green-100 rounded-lg p-3">
                <ShieldCheck className="h-4 w-4 text-green-600 shrink-0" />
                <span>Pago seguro procesado por <strong>Azul</strong> – Tarjetas dominicanas e internacionales</span>
              </div>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="cardName" className="text-sm font-medium">Nombre en la tarjeta</Label>
                  <Input
                    id="cardName"
                    placeholder="Ej. JUAN PÉREZ"
                    value={cardName}
                    onChange={e => setCardName(e.target.value.toUpperCase())}
                    className="mt-1.5 rounded-lg"
                    data-testid="input-card-name"
                  />
                </div>
                <div>
                  <Label htmlFor="cardNumber" className="text-sm font-medium">Número de tarjeta</Label>
                  <Input
                    id="cardNumber"
                    placeholder="0000 0000 0000 0000"
                    value={cardNumber}
                    onChange={e => setCardNumber(formatCardNumber(e.target.value))}
                    maxLength={19}
                    className="mt-1.5 rounded-lg font-mono tracking-widest"
                    data-testid="input-card-number"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="expiry" className="text-sm font-medium">Vencimiento</Label>
                    <Input
                      id="expiry"
                      placeholder="MM/AA"
                      value={expiry}
                      onChange={e => setExpiry(formatExpiry(e.target.value))}
                      maxLength={5}
                      className="mt-1.5 rounded-lg"
                      data-testid="input-expiry"
                    />
                  </div>
                  <div>
                    <Label htmlFor="cvv" className="text-sm font-medium">CVV</Label>
                    <Input
                      id="cvv"
                      placeholder="123"
                      value={cvv}
                      onChange={e => setCvv(e.target.value.replace(/\D/g, "").substring(0, 4))}
                      maxLength={4}
                      className="mt-1.5 rounded-lg"
                      data-testid="input-cvv"
                    />
                  </div>
                </div>
              </div>

              <div className="text-xs text-muted-foreground bg-muted/50 rounded-lg p-3 space-y-1">
                <div className="flex justify-between"><span>Subtotal</span><span>RD${azulAmountDOP.toFixed(2)}</span></div>
                <div className="flex justify-between"><span>ITBIS (18%)</span><span>RD${itbisDOP.toFixed(2)}</span></div>
                <div className="flex justify-between font-semibold text-foreground border-t border-border pt-1 mt-1">
                  <span>Total</span>
                  <span>RD${azulTotalDOP.toFixed(2)}</span>
                </div>
                {currency === "USD" && (
                  <p className="text-xs text-muted-foreground pt-1 text-center opacity-70">
                    Conversión aproximada de ${priceInUnits.toFixed(2)} USD
                  </p>
                )}
              </div>

              <Button
                className="w-full h-12 bg-accent text-white rounded-xl font-semibold text-base shadow-md"
                onClick={handleAzulPayment}
                disabled={isProcessing}
                data-testid="button-pay-azul"
              >
                {isProcessing ? (
                  <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Procesando...</>
                ) : (
                  <>Pagar con Azul – RD${azulTotalDOP.toFixed(2)}</>
                )}
              </Button>
            </TabsContent>

            {/* PayPal Tab (USD only) */}
            {isPayPalAvailable && (
              <TabsContent value="paypal" className="mt-0">
                <div className="flex items-center gap-2 text-xs text-muted-foreground bg-blue-50 border border-blue-100 rounded-lg p-3 mb-4">
                  <ShieldCheck className="h-4 w-4 text-blue-600 shrink-0" />
                  <span>Paga de forma segura con tu cuenta PayPal o tarjeta internacional.</span>
                </div>

                <div className="text-xs text-muted-foreground bg-muted/50 rounded-lg p-3 mb-4">
                  <div className="flex justify-between font-semibold text-foreground">
                    <span>Total a pagar</span>
                    <span>${priceUSD} USD</span>
                  </div>
                </div>

                <div className="flex justify-center py-4">
                  <PayPalButton
                    amount={priceUSD}
                    currency="USD"
                    intent="CAPTURE"
                  />
                </div>

                <p className="text-center text-xs text-muted-foreground mt-2">
                  Al completar el pago recibirás acceso inmediato al curso.
                </p>
              </TabsContent>
            )}
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  );
}
