import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { LogOut, BookOpen, LayoutDashboard, UserCircle } from "lucide-react";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export function Navbar() {
  const { user, isAuthenticated, logout } = useAuth();
  const isInstructor = user?.role === "instructor";

  return (
    <nav className="sticky top-0 z-50 w-full bg-white/90 backdrop-blur-md border-b border-border/50 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex-shrink-0 flex items-center">
            <Link href="/" className="flex items-center gap-2">
              <img 
                src="https://wpsconsultingroup.com/img/fondo.png" 
                alt="WPS Consulting Group" 
                className="h-10 object-contain"
              />
              <span className="font-display font-bold text-lg hidden sm:inline-block ml-1 text-foreground">
                Academia
              </span>
            </Link>
          </div>
          
          <div className="flex items-center gap-3">
            <Link href="/#cursos" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors hidden sm:block">
              Cursos
            </Link>
            <a 
              href="https://wpsconsultingroup.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors hidden sm:block"
            >
              WPS Consulting
            </a>
            
            {isAuthenticated && user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-10 w-10 rounded-full" data-testid="button-user-menu">
                    <Avatar className="h-10 w-10 border-2 border-accent/30">
                      <AvatarImage src={user.profileImageUrl || ''} alt={user.firstName || 'Usuario'} />
                      <AvatarFallback className="bg-accent/10 text-accent">
                        {user.firstName?.[0] || <UserCircle className="h-5 w-5" />}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56" align="end" forceMount>
                  <DropdownMenuLabel className="font-normal">
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none">{user.firstName} {user.lastName}</p>
                      <p className="text-xs leading-none text-muted-foreground">{user.email}</p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/dashboard" className="cursor-pointer flex w-full items-center" data-testid="link-mi-aprendizaje">
                      <BookOpen className="mr-2 h-4 w-4" />
                      <span>Mi Aprendizaje</span>
                    </Link>
                  </DropdownMenuItem>
                  {isInstructor && (
                    <DropdownMenuItem asChild>
                      <Link href="/instructor" className="cursor-pointer flex w-full items-center" data-testid="link-instructor">
                        <LayoutDashboard className="mr-2 h-4 w-4" />
                        <span>Panel de Instructor</span>
                      </Link>
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem 
                    className="text-destructive cursor-pointer focus:text-destructive" 
                    onClick={() => logout()}
                    data-testid="button-logout"
                  >
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Cerrar sesión</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <div className="flex items-center gap-2">
                <Button asChild variant="ghost" className="text-sm font-medium" data-testid="button-login">
                  <Link href="/login">Iniciar sesión</Link>
                </Button>
                <Button asChild className="bg-[#DF8700] hover:bg-[#c47800] text-white rounded-full px-5 font-semibold shadow-md transition-all text-sm" data-testid="button-register">
                  <Link href="/register">Registrarse</Link>
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
