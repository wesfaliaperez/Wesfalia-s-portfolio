import { useQuery, useMutation } from "@tanstack/react-query";
import { type PurchaseResponse } from "@shared/schema";

export function usePurchases() {
  return useQuery<PurchaseResponse[]>({
    queryKey: ["/api/purchases"],
    queryFn: async () => {
      const res = await fetch("/api/purchases");
      if (res.status === 401) return [];
      if (!res.ok) throw new Error("Failed to fetch purchases");
      return res.json();
    },
  });
}

export function useCheckout() {
  return useMutation({
    mutationFn: async (courseId: number) => {
      const res = await fetch(`/api/courses/${courseId}/checkout`, {
        method: "POST",
      });
      if (!res.ok) {
        const error = await res.json().catch(() => ({ message: "Checkout failed" }));
        throw new Error(error.message || "Failed to initiate checkout");
      }
      return res.json() as Promise<{ url: string }>;
    },
    onSuccess: (data) => {
      if (data.url) {
        window.location.href = data.url;
      }
    }
  });
}
