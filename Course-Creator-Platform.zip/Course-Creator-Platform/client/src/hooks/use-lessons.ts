import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { type LessonResponse, type CreateLessonRequest, type UpdateLessonRequest } from "@shared/schema";

export function useLessons(courseId: number) {
  return useQuery<LessonResponse[]>({
    queryKey: ["/api/courses", courseId, "lessons"],
    queryFn: async () => {
      const res = await fetch(`/api/courses/${courseId}/lessons`);
      if (!res.ok) throw new Error("Failed to fetch lessons");
      return res.json();
    },
    enabled: !!courseId,
  });
}

export function useCreateLesson(courseId: number) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: Omit<CreateLessonRequest, "courseId">) => {
      const res = await fetch(`/api/courses/${courseId}/lessons`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create lesson");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/courses", courseId, "lessons"] });
    },
  });
}

export function useUpdateLesson(courseId: number) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...data }: { id: number } & UpdateLessonRequest) => {
      const res = await fetch(`/api/lessons/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to update lesson");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/courses", courseId, "lessons"] });
    },
  });
}

export function useDeleteLesson(courseId: number) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/lessons/${id}`, {
        method: "DELETE",
      });
      if (!res.ok) throw new Error("Failed to delete lesson");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/courses", courseId, "lessons"] });
    },
  });
}
