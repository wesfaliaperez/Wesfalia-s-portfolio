import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import CourseDetails from "@/pages/CourseDetails";
import StudentDashboard from "@/pages/StudentDashboard";
import LessonPlayer from "@/pages/LessonPlayer";
import InstructorDashboard from "@/pages/InstructorDashboard";
import EditCourse from "@/pages/EditCourse";
import Login from "@/pages/Login";
import Register from "@/pages/Register";

function Router() {
  return (
    <Switch>
      {/* Public Routes */}
      <Route path="/" component={Home}/>
      <Route path="/courses/:id" component={CourseDetails} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      
      {/* Student Routes */}
      <Route path="/dashboard" component={StudentDashboard} />
      <Route path="/dashboard/courses/:id/learn" component={LessonPlayer} />
      
      {/* Instructor Routes */}
      <Route path="/instructor" component={InstructorDashboard} />
      <Route path="/instructor/courses/new" component={EditCourse} />
      <Route path="/instructor/courses/:id/edit" component={EditCourse} />
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
