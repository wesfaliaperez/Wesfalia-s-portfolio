import { z } from 'zod';
import { insertCourseSchema, insertLessonSchema, courses, lessons, purchases } from './schema';

export const errorSchemas = {
  validation: z.object({ message: z.string(), field: z.string().optional() }),
  notFound: z.object({ message: z.string() }),
  unauthorized: z.object({ message: z.string() }),
  internal: z.object({ message: z.string() }),
};

export const api = {
  courses: {
    list: {
      method: 'GET' as const,
      path: '/api/courses' as const,
      responses: {
        200: z.array(z.custom<any>()), // CourseResponse
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/courses/:id' as const,
      responses: {
        200: z.custom<any>(), // CourseResponse
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/courses' as const,
      input: insertCourseSchema.omit({ instructorId: true }),
      responses: {
        201: z.custom<typeof courses.$inferSelect>(),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/courses/:id' as const,
      input: insertCourseSchema.partial(),
      responses: {
        200: z.custom<typeof courses.$inferSelect>(),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
        404: errorSchemas.notFound,
      },
    },
  },
  lessons: {
    list: {
      method: 'GET' as const,
      path: '/api/courses/:courseId/lessons' as const,
      responses: {
        200: z.array(z.custom<typeof lessons.$inferSelect>()),
      }
    },
    create: {
      method: 'POST' as const,
      path: '/api/courses/:courseId/lessons' as const,
      input: insertLessonSchema.omit({ courseId: true }),
      responses: {
        201: z.custom<typeof lessons.$inferSelect>(),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/lessons/:id' as const,
      input: insertLessonSchema.partial(),
      responses: {
        200: z.custom<typeof lessons.$inferSelect>(),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/lessons/:id' as const,
      responses: {
        204: z.void(),
        401: errorSchemas.unauthorized,
        404: errorSchemas.notFound,
      },
    }
  },
  purchases: {
    list: {
      method: 'GET' as const,
      path: '/api/purchases' as const,
      responses: {
        200: z.array(z.custom<any>()), // PurchaseResponse
        401: errorSchemas.unauthorized,
      },
    },
    createCheckout: {
      method: 'POST' as const,
      path: '/api/courses/:courseId/checkout' as const,
      responses: {
        200: z.object({ url: z.string() }),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
        404: errorSchemas.notFound,
      }
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
